-- ============================================================================
-- MUBEEN AKHTAR CREATOR HUB — DATABASE SCHEMA (Phase 1)
-- ============================================================================
-- Run this entire file in Supabase Studio -> SQL Editor -> New Query -> Run.
-- Safe to re-run: uses IF NOT EXISTS / CREATE OR REPLACE where possible.
--
-- Design notes (read before running):
-- 1. Auth/roles: we do NOT store "is admin" as a hardcoded flag on a shared
--    profiles table used for the public bio. Instead:
--      - `user_roles` maps a Supabase Auth user (auth.users) to a role.
--        Phase 1 only ever has role='admin' rows (created manually by you).
--        Phase 2/3 can add 'creator' / 'student' roles without any schema
--        change to this table.
--      - `site_profile` is a SINGLE public-facing row holding the "About Me"
--        content (bio, journey, interests, skills, vision). It is NOT the
--        same thing as an auth user's profile — it's CMS-style content.
-- 2. Anonymous abuse prevention: ratings/likes/reviews from public visitors
--    are tied to a random `session_id` (a UUID generated client-side and
--    stored in a cookie/localStorage, NOT a real identity). A unique
--    constraint stops the same session from rating/liking the same item
--    twice. This is intentionally "obvious abuse" prevention only, per
--    spec — it is not fraud-proof, and the schema leaves `user_id` columns
--    ready for Phase 2 when real authenticated users can rate instead.
-- 3. Every public-write table separates INSERT (open, constrained) from
--    UPDATE/DELETE (admin-only) at the RLS policy level.
-- ============================================================================

create extension if not exists "uuid-ossp";

-- ----------------------------------------------------------------------------
-- 1. user_roles — links Supabase Auth users to a role. Admin rows are created
--    manually (see README) by inserting the row after creating the auth user.
-- ----------------------------------------------------------------------------
create table if not exists public.user_roles (
  user_id    uuid primary key references auth.users(id) on delete cascade,
  role       text not null default 'admin' check (role in ('admin', 'creator', 'student')),
  created_at timestamptz not null default now()
);

create or replace function public.is_admin()
returns boolean
language sql
security definer
stable
set search_path = public
as $$
  select exists (
    select 1 from public.user_roles
    where user_id = auth.uid() and role = 'admin'
  );
$$;

-- ----------------------------------------------------------------------------
-- 2. site_profile — singleton "About Me" content, editable from admin.
-- ----------------------------------------------------------------------------
create table if not exists public.site_profile (
  id            uuid primary key default uuid_generate_v4(),
  display_name  text not null default 'Mubeen Akhtar',
  tagline       text not null default '',
  short_intro   text not null default '',
  bio           text not null default '',
  journey       text not null default '',
  interests     text[] not null default '{}',
  skills        text[] not null default '{}',
  future_vision text not null default '',
  avatar_url    text,
  hero_image_url text,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

-- ----------------------------------------------------------------------------
-- 3. site_settings — key config the admin can change (SEO, contact email,
--    feature flags). Singleton row, same pattern as site_profile.
-- ----------------------------------------------------------------------------
create table if not exists public.site_settings (
  id                    uuid primary key default uuid_generate_v4(),
  site_title            text not null default 'Mubeen Akhtar | Creator Hub',
  site_description      text not null default 'Personal creator hub — photos, videos, socials and more.',
  og_image_url          text,
  contact_email         text,
  reviews_require_review boolean not null default true,
  ai_zone_enabled       boolean not null default false,
  maintenance_mode      boolean not null default false,
  updated_at            timestamptz not null default now()
);

-- ----------------------------------------------------------------------------
-- 4. social_accounts
-- ----------------------------------------------------------------------------
create table if not exists public.social_accounts (
  id              uuid primary key default uuid_generate_v4(),
  platform        text not null check (platform in
                    ('tiktok','instagram','youtube','facebook','snapchat','x','linkedin','other')),
  username        text not null,
  profile_url     text not null,
  icon            text,                 -- optional custom icon override; platform has a default icon in UI
  follower_count  integer check (follower_count is null or follower_count >= 0),
  display_order   integer not null default 0,
  is_active       boolean not null default true,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);
create index if not exists idx_social_accounts_active_order
  on public.social_accounts (is_active, display_order);

-- ----------------------------------------------------------------------------
-- 5. albums
-- ----------------------------------------------------------------------------
create table if not exists public.albums (
  id              uuid primary key default uuid_generate_v4(),
  title           text not null,
  slug            text not null unique,
  description     text,
  cover_photo_url text,
  display_order   integer not null default 0,
  is_active       boolean not null default true,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);
create index if not exists idx_albums_active_order on public.albums (is_active, display_order);

-- ----------------------------------------------------------------------------
-- 6. photos
-- ----------------------------------------------------------------------------
create table if not exists public.photos (
  id             uuid primary key default uuid_generate_v4(),
  album_id       uuid references public.albums(id) on delete set null,
  title          text not null,
  description    text,
  storage_path   text not null,   -- path inside the "photos" storage bucket
  is_featured    boolean not null default false,
  is_published   boolean not null default true,
  display_order  integer not null default 0,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);
create index if not exists idx_photos_album on public.photos (album_id);
create index if not exists idx_photos_published_order on public.photos (is_published, display_order);
create index if not exists idx_photos_featured on public.photos (is_featured) where is_featured = true;

-- ----------------------------------------------------------------------------
-- 7. videos
-- ----------------------------------------------------------------------------
create table if not exists public.videos (
  id             uuid primary key default uuid_generate_v4(),
  title          text not null,
  description    text,
  category       text,
  source_type    text not null check (source_type in ('storage','external')),
  storage_path   text,          -- set when source_type = 'storage'
  external_url   text,          -- set when source_type = 'external' (e.g. YouTube/TikTok link)
  thumbnail_url  text,
  is_featured    boolean not null default false,
  is_published   boolean not null default true,
  display_order  integer not null default 0,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  constraint videos_source_consistency check (
    (source_type = 'storage' and storage_path is not null) or
    (source_type = 'external' and external_url is not null)
  )
);
create index if not exists idx_videos_published_order on public.videos (is_published, display_order);
create index if not exists idx_videos_featured on public.videos (is_featured) where is_featured = true;
create index if not exists idx_videos_category on public.videos (category);

-- ----------------------------------------------------------------------------
-- 8. ratings — 1..5 stars on a photo or video. Anonymous in Phase 1, with
--    user_id reserved for Phase 2 authenticated ratings.
-- ----------------------------------------------------------------------------
create table if not exists public.ratings (
  id           uuid primary key default uuid_generate_v4(),
  target_type  text not null check (target_type in ('photo','video')),
  target_id    uuid not null,
  stars        integer not null check (stars between 1 and 5),
  session_id   text not null,
  user_id      uuid references auth.users(id) on delete set null,
  created_at   timestamptz not null default now(),
  unique (target_type, target_id, session_id)
);
create index if not exists idx_ratings_target on public.ratings (target_type, target_id);

-- ----------------------------------------------------------------------------
-- 9. content_likes — one like per session per item.
-- ----------------------------------------------------------------------------
create table if not exists public.content_likes (
  id           uuid primary key default uuid_generate_v4(),
  target_type  text not null check (target_type in ('photo','video')),
  target_id    uuid not null,
  session_id   text not null,
  created_at   timestamptz not null default now(),
  unique (target_type, target_id, session_id)
);
create index if not exists idx_likes_target on public.content_likes (target_type, target_id);

-- ----------------------------------------------------------------------------
-- 10. reviews — audience feedback, moderated before public display.
-- ----------------------------------------------------------------------------
create table if not exists public.reviews (
  id            uuid primary key default uuid_generate_v4(),
  display_name  text not null,
  message       text not null,
  stars         integer not null check (stars between 1 and 5),
  status        text not null default 'pending' check (status in ('pending','approved','hidden')),
  is_featured   boolean not null default false,
  session_id    text not null,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index if not exists idx_reviews_status on public.reviews (status, created_at desc);

-- ----------------------------------------------------------------------------
-- 11. contact_messages — private inbox, admin-only read.
-- ----------------------------------------------------------------------------
create table if not exists public.contact_messages (
  id         uuid primary key default uuid_generate_v4(),
  name       text not null,
  email      text not null,
  message    text not null,
  status     text not null default 'new' check (status in ('new','read','archived')),
  created_at timestamptz not null default now()
);
create index if not exists idx_contact_status on public.contact_messages (status, created_at desc);

-- ----------------------------------------------------------------------------
-- updated_at trigger helper (applied to every table that has updated_at)
-- ----------------------------------------------------------------------------
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

do $$
declare t text;
begin
  foreach t in array array['site_profile','site_settings','social_accounts','albums','photos','videos','reviews']
  loop
    execute format('drop trigger if exists trg_set_updated_at on public.%I;', t);
    execute format('create trigger trg_set_updated_at before update on public.%I
                     for each row execute function public.set_updated_at();', t);
  end loop;
end $$;

-- ============================================================================
-- ROW LEVEL SECURITY
-- ============================================================================
alter table public.user_roles      enable row level security;
alter table public.site_profile    enable row level security;
alter table public.site_settings   enable row level security;
alter table public.social_accounts enable row level security;
alter table public.albums          enable row level security;
alter table public.photos          enable row level security;
alter table public.videos          enable row level security;
alter table public.ratings         enable row level security;
alter table public.content_likes   enable row level security;
alter table public.reviews         enable row level security;
alter table public.contact_messages enable row level security;

-- user_roles: nobody except admins can read/write via the client. Server
-- checks use the security-definer is_admin() function above, which bypasses
-- RLS internally — this table itself stays locked down.
drop policy if exists "user_roles_admin_all" on public.user_roles;
create policy "user_roles_admin_all" on public.user_roles
  for all using (public.is_admin()) with check (public.is_admin());

-- site_profile: public read, admin write
drop policy if exists "site_profile_public_read" on public.site_profile;
create policy "site_profile_public_read" on public.site_profile for select using (true);
drop policy if exists "site_profile_admin_write" on public.site_profile;
create policy "site_profile_admin_write" on public.site_profile
  for insert with check (public.is_admin());
drop policy if exists "site_profile_admin_update" on public.site_profile;
create policy "site_profile_admin_update" on public.site_profile
  for update using (public.is_admin()) with check (public.is_admin());
drop policy if exists "site_profile_admin_delete" on public.site_profile;
create policy "site_profile_admin_delete" on public.site_profile
  for delete using (public.is_admin());

-- site_settings: public read, admin write
drop policy if exists "site_settings_public_read" on public.site_settings;
create policy "site_settings_public_read" on public.site_settings for select using (true);
drop policy if exists "site_settings_admin_write" on public.site_settings;
create policy "site_settings_admin_write" on public.site_settings
  for insert with check (public.is_admin());
drop policy if exists "site_settings_admin_update" on public.site_settings;
create policy "site_settings_admin_update" on public.site_settings
  for update using (public.is_admin()) with check (public.is_admin());

-- social_accounts: public reads active rows, admin manages all
drop policy if exists "social_public_read" on public.social_accounts;
create policy "social_public_read" on public.social_accounts for select using (is_active = true or public.is_admin());
drop policy if exists "social_admin_write" on public.social_accounts;
create policy "social_admin_write" on public.social_accounts for insert with check (public.is_admin());
drop policy if exists "social_admin_update" on public.social_accounts;
create policy "social_admin_update" on public.social_accounts for update using (public.is_admin()) with check (public.is_admin());
drop policy if exists "social_admin_delete" on public.social_accounts;
create policy "social_admin_delete" on public.social_accounts for delete using (public.is_admin());

-- albums: public reads active, admin manages all
drop policy if exists "albums_public_read" on public.albums;
create policy "albums_public_read" on public.albums for select using (is_active = true or public.is_admin());
drop policy if exists "albums_admin_write" on public.albums;
create policy "albums_admin_write" on public.albums for insert with check (public.is_admin());
drop policy if exists "albums_admin_update" on public.albums;
create policy "albums_admin_update" on public.albums for update using (public.is_admin()) with check (public.is_admin());
drop policy if exists "albums_admin_delete" on public.albums;
create policy "albums_admin_delete" on public.albums for delete using (public.is_admin());

-- photos: public reads published, admin manages all
drop policy if exists "photos_public_read" on public.photos;
create policy "photos_public_read" on public.photos for select using (is_published = true or public.is_admin());
drop policy if exists "photos_admin_write" on public.photos;
create policy "photos_admin_write" on public.photos for insert with check (public.is_admin());
drop policy if exists "photos_admin_update" on public.photos;
create policy "photos_admin_update" on public.photos for update using (public.is_admin()) with check (public.is_admin());
drop policy if exists "photos_admin_delete" on public.photos;
create policy "photos_admin_delete" on public.photos for delete using (public.is_admin());

-- videos: same pattern
drop policy if exists "videos_public_read" on public.videos;
create policy "videos_public_read" on public.videos for select using (is_published = true or public.is_admin());
drop policy if exists "videos_admin_write" on public.videos;
create policy "videos_admin_write" on public.videos for insert with check (public.is_admin());
drop policy if exists "videos_admin_update" on public.videos;
create policy "videos_admin_update" on public.videos for update using (public.is_admin()) with check (public.is_admin());
drop policy if exists "videos_admin_delete" on public.videos;
create policy "videos_admin_delete" on public.videos for delete using (public.is_admin());

-- ratings: public can read (to compute averages) and insert their own
-- session's rating; nobody but admin can update/delete.
drop policy if exists "ratings_public_read" on public.ratings;
create policy "ratings_public_read" on public.ratings for select using (true);
drop policy if exists "ratings_public_insert" on public.ratings;
create policy "ratings_public_insert" on public.ratings for insert with check (true);
drop policy if exists "ratings_admin_delete" on public.ratings;
create policy "ratings_admin_delete" on public.ratings for delete using (public.is_admin());

-- content_likes: same open-insert / admin-delete pattern
drop policy if exists "likes_public_read" on public.content_likes;
create policy "likes_public_read" on public.content_likes for select using (true);
drop policy if exists "likes_public_insert" on public.content_likes;
create policy "likes_public_insert" on public.content_likes for insert with check (true);
drop policy if exists "likes_admin_delete" on public.content_likes;
create policy "likes_admin_delete" on public.content_likes for delete using (public.is_admin());

-- reviews: public can read only approved rows (or admin reads all); public
-- can insert but ONLY with status='pending' — they cannot self-approve.
drop policy if exists "reviews_public_read" on public.reviews;
create policy "reviews_public_read" on public.reviews
  for select using (status = 'approved' or public.is_admin());
drop policy if exists "reviews_public_insert" on public.reviews;
create policy "reviews_public_insert" on public.reviews
  for insert with check (status = 'pending' and is_featured = false);
drop policy if exists "reviews_admin_update" on public.reviews;
create policy "reviews_admin_update" on public.reviews
  for update using (public.is_admin()) with check (public.is_admin());
drop policy if exists "reviews_admin_delete" on public.reviews;
create policy "reviews_admin_delete" on public.reviews for delete using (public.is_admin());

-- contact_messages: public can INSERT ONLY — no select at all for anon,
-- admin can read/update/delete.
drop policy if exists "contact_public_insert" on public.contact_messages;
create policy "contact_public_insert" on public.contact_messages for insert with check (true);
drop policy if exists "contact_admin_read" on public.contact_messages;
create policy "contact_admin_read" on public.contact_messages for select using (public.is_admin());
drop policy if exists "contact_admin_update" on public.contact_messages;
create policy "contact_admin_update" on public.contact_messages for update using (public.is_admin()) with check (public.is_admin());
drop policy if exists "contact_admin_delete" on public.contact_messages;
create policy "contact_admin_delete" on public.contact_messages for delete using (public.is_admin());

-- ----------------------------------------------------------------------------
-- Seed the two singleton rows (site_profile, site_settings) if empty. This is
-- structural seed data, not fake content — every field is blank/placeholder
-- and must be filled in from the admin dashboard.
-- ----------------------------------------------------------------------------
insert into public.site_profile (display_name, tagline, short_intro, bio, journey, future_vision)
select 'Mubeen Akhtar', '', '', '', '', ''
where not exists (select 1 from public.site_profile);

insert into public.site_settings (site_title, site_description)
select 'Mubeen Akhtar | Creator Hub', 'Personal creator hub — photos, videos, socials and more.'
where not exists (select 1 from public.site_settings);
