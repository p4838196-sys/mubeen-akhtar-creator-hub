-- ============================================================================
-- STORAGE POLICIES
-- ============================================================================
-- IMPORTANT: Create these THREE buckets first in Supabase Studio -> Storage
-- -> New bucket, BEFORE running this file:
--
--   1. photos   (Public bucket: ON)
--   2. videos   (Public bucket: ON)
--   3. avatars  (Public bucket: ON)
--
-- They're public-READ buckets because Phase 1 content is a public creator
-- profile — but WRITE/DELETE is still locked to admins only via the
-- policies below (storage.objects RLS). Public "bucket" just means anyone
-- with the file URL can view it; it does NOT mean anyone can upload/delete.
-- ============================================================================

-- Public read for all three buckets
drop policy if exists "public_read_photos" on storage.objects;
create policy "public_read_photos" on storage.objects
  for select using (bucket_id = 'photos');

drop policy if exists "public_read_videos" on storage.objects;
create policy "public_read_videos" on storage.objects
  for select using (bucket_id = 'videos');

drop policy if exists "public_read_avatars" on storage.objects;
create policy "public_read_avatars" on storage.objects
  for select using (bucket_id = 'avatars');

-- Admin-only write/update/delete on all three buckets
drop policy if exists "admin_write_photos" on storage.objects;
create policy "admin_write_photos" on storage.objects
  for insert with check (bucket_id = 'photos' and public.is_admin());

drop policy if exists "admin_update_photos" on storage.objects;
create policy "admin_update_photos" on storage.objects
  for update using (bucket_id = 'photos' and public.is_admin());

drop policy if exists "admin_delete_photos" on storage.objects;
create policy "admin_delete_photos" on storage.objects
  for delete using (bucket_id = 'photos' and public.is_admin());

drop policy if exists "admin_write_videos" on storage.objects;
create policy "admin_write_videos" on storage.objects
  for insert with check (bucket_id = 'videos' and public.is_admin());

drop policy if exists "admin_update_videos" on storage.objects;
create policy "admin_update_videos" on storage.objects
  for update using (bucket_id = 'videos' and public.is_admin());

drop policy if exists "admin_delete_videos" on storage.objects;
create policy "admin_delete_videos" on storage.objects
  for delete using (bucket_id = 'videos' and public.is_admin());

drop policy if exists "admin_write_avatars" on storage.objects;
create policy "admin_write_avatars" on storage.objects
  for insert with check (bucket_id = 'avatars' and public.is_admin());

drop policy if exists "admin_update_avatars" on storage.objects;
create policy "admin_update_avatars" on storage.objects
  for update using (bucket_id = 'avatars' and public.is_admin());

drop policy if exists "admin_delete_avatars" on storage.objects;
create policy "admin_delete_avatars" on storage.objects
  for delete using (bucket_id = 'avatars' and public.is_admin());
