/** @type {import('next').NextConfig} */
const supabaseHostname = (() => {
  try {
    const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
    return url ? new URL(url).hostname : undefined;
  } catch {
    return undefined;
  }
})();

const nextConfig = {
  reactStrictMode: true,
  images: {
    // Next/Image needs explicit remote hosts. Supabase Storage public URLs
    // live on <project-ref>.supabase.co, derived here from your env var so
    // you don't have to hardcode it. External video thumbnails (e.g.
    // YouTube) are added explicitly below — add more if you use other
    // platforms for external video thumbnails.
    remotePatterns: [
      ...(supabaseHostname
        ? [{ protocol: 'https', hostname: supabaseHostname, pathname: '/storage/v1/object/public/**' }]
        : []),
      { protocol: 'https', hostname: 'i.ytimg.com' },
      { protocol: 'https', hostname: 'img.youtube.com' },
    ],
    formats: ['image/avif', 'image/webp'],
  },
};

export default nextConfig;
