import { createClient } from '@/lib/supabase/server';
import type { UserRole } from '@/lib/types/database.types';

export interface AdminUser {
  id: string;
  email: string | null;
  role: UserRole;
}

/**
 * Resolves the currently logged-in admin, or null if there is no session
 * OR the session belongs to a user without an 'admin' row in `user_roles`.
 * Every admin page/action should treat `null` as "not authorized" — this
 * is the single source of truth used across admin layout + pages, so the
 * check is consistent everywhere instead of re-implemented per page.
 */
export async function getCurrentAdminUser(): Promise<AdminUser | null> {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return null;

  const { data: roleRow } = await supabase
    .from('user_roles')
    .select('role')
    .eq('user_id', user.id)
    .eq('role', 'admin')
    .maybeSingle();

  if (!roleRow) return null;

  return { id: user.id, email: user.email ?? null, role: roleRow.role };
}
