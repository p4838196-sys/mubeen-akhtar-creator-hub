import { createClient } from '@/lib/supabase/server';
import { summarizeRatings } from '@/lib/utils/ratings';
import type { RatingSummary, RatingTargetType } from '@/lib/types/database.types';

export async function getRatingSummary(targetType: RatingTargetType, targetId: string): Promise<RatingSummary> {
  const supabase = await createClient();
  const { data, error } = await supabase.from('ratings').select('stars').eq('target_type', targetType).eq('target_id', targetId);
  if (error) {
    console.error('getRatingSummary error', error.message);
    return { average: null, count: 0, distribution: { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 } };
  }
  return summarizeRatings(data ?? []);
}

/** One query for N items instead of N queries — used by list/grid pages. */
export async function getRatingSummariesBulk(
  targetType: RatingTargetType,
  targetIds: string[]
): Promise<Record<string, RatingSummary>> {
  if (targetIds.length === 0) return {};
  const supabase = await createClient();
  const { data, error } = await supabase
    .from('ratings')
    .select('target_id, stars')
    .eq('target_type', targetType)
    .in('target_id', targetIds);

  const byId: Record<string, { stars: number }[]> = {};
  if (!error) {
    for (const row of data ?? []) {
      (byId[row.target_id] ??= []).push({ stars: row.stars });
    }
  }
  const result: Record<string, RatingSummary> = {};
  for (const id of targetIds) result[id] = summarizeRatings(byId[id] ?? []);
  return result;
}

export async function getLikeCountsBulk(targetType: RatingTargetType, targetIds: string[]): Promise<Record<string, number>> {
  if (targetIds.length === 0) return {};
  const supabase = await createClient();
  const { data, error } = await supabase.from('content_likes').select('target_id').eq('target_type', targetType).in('target_id', targetIds);
  const counts: Record<string, number> = {};
  for (const id of targetIds) counts[id] = 0;
  if (!error) {
    for (const row of data ?? []) counts[row.target_id] = (counts[row.target_id] ?? 0) + 1;
  }
  return counts;
}

export async function getLikeCount(targetType: RatingTargetType, targetId: string): Promise<number> {
  const supabase = await createClient();
  const { count, error } = await supabase
    .from('content_likes')
    .select('id', { count: 'exact', head: true })
    .eq('target_type', targetType)
    .eq('target_id', targetId);
  if (error) {
    console.error('getLikeCount error', error.message);
    return 0;
  }
  return count ?? 0;
}
