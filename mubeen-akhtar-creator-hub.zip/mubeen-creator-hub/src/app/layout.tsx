import type { Metadata } from 'next';
import { Inter, Plus_Jakarta_Sans } from 'next/font/google';
import './globals.css';
import { Navbar } from '@/components/layout/Navbar';
import { Footer } from '@/components/layout/Footer';
import { getSiteProfile } from '@/lib/data/profile';
import { getSiteSettings } from '@/lib/data/settings';
import { getActiveSocialAccounts } from '@/lib/data/social';

const inter = Inter({ subsets: ['latin'], variable: '--font-sans', display: 'swap' });
const jakarta = Plus_Jakarta_Sans({ subsets: ['latin'], variable: '--font-display', weight: ['600', '700', '800'], display: 'swap' });

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000';

export async function generateMetadata(): Promise<Metadata> {
  const settings = await getSiteSettings();
  const title = settings?.site_title || 'Mubeen Akhtar | Creator Hub';
  const description = settings?.site_description || 'Personal creator hub — photos, videos, socials and more.';

  return {
    metadataBase: new URL(siteUrl),
    title: { default: title, template: `%s | ${title}` },
    description,
    openGraph: {
      title,
      description,
      url: siteUrl,
      siteName: title,
      images: settings?.og_image_url ? [{ url: settings.og_image_url }] : undefined,
      type: 'website',
    },
    twitter: {
      card: 'summary_large_image',
      title,
      description,
      images: settings?.og_image_url ? [settings.og_image_url] : undefined,
    },
    robots: { index: true, follow: true },
  };
}

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const [profile, socials] = await Promise.all([getSiteProfile(), getActiveSocialAccounts()]);
  const displayName = profile?.display_name || 'Mubeen Akhtar';

  return (
    <html lang="en" className={`${inter.variable} ${jakarta.variable}`}>
      <body className="flex min-h-screen flex-col">
        <Navbar displayName={displayName} />
        <main className="flex-1">{children}</main>
        <Footer displayName={displayName} socials={socials} />
      </body>
    </html>
  );
}
