import Link from 'next/link';
import { getDashboardStats } from '@/lib/data/stats';
import { StatCard } from '@/components/admin/StatCard';

export default async function AdminOverviewPage() {
  const stats = await getDashboardStats();

  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-ink-950">Overview</h1>
      <p className="mt-1 text-sm text-ink-900/50">Live numbers pulled directly from your Supabase database.</p>

      <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
        <StatCard label="Total Photos" value={String(stats.totalPhotos)} />
        <StatCard label="Total Videos" value={String(stats.totalVideos)} />
        <StatCard label="Total Ratings" value={String(stats.totalRatings)} />
        <StatCard
          label="Average Rating"
          value={stats.averageRating !== null ? stats.averageRating.toFixed(1) : '—'}
          hint={stats.averageRating === null ? 'No ratings yet' : undefined}
        />
        <StatCard label="Total Reviews" value={String(stats.totalReviews)} hint={`${stats.pendingReviews} pending`} />
        <StatCard label="Contact Messages" value={String(stats.totalMessages)} hint={`${stats.unreadMessages} unread`} />
      </div>

      <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <Link href="/admin/photos" className="rounded-xl2 border border-ink-900/8 bg-white p-5 shadow-card transition-shadow hover:shadow-lg">
          <p className="font-display text-base font-semibold text-ink-950">Manage Photos</p>
          <p className="mt-1 text-sm text-ink-900/50">Upload, edit and organize your photo gallery.</p>
        </Link>
        <Link href="/admin/videos" className="rounded-xl2 border border-ink-900/8 bg-white p-5 shadow-card transition-shadow hover:shadow-lg">
          <p className="font-display text-base font-semibold text-ink-950">Manage Videos</p>
          <p className="mt-1 text-sm text-ink-900/50">Add hosted or external videos.</p>
        </Link>
        <Link href="/admin/messages" className="rounded-xl2 border border-ink-900/8 bg-white p-5 shadow-card transition-shadow hover:shadow-lg">
          <p className="font-display text-base font-semibold text-ink-950">Contact Inbox</p>
          <p className="mt-1 text-sm text-ink-900/50">{stats.unreadMessages} unread message{stats.unreadMessages !== 1 ? 's' : ''}.</p>
        </Link>
      </div>
    </div>
  );
}
