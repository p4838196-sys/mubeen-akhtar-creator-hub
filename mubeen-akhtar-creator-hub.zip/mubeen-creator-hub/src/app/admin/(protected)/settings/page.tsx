import { getSiteProfile } from '@/lib/data/profile';
import { getSiteSettings } from '@/lib/data/settings';
import { ProfileSettingsForm } from '@/components/admin/settings/ProfileSettingsForm';
import { ProfileImageForm } from '@/components/admin/settings/ProfileImageForm';
import { SiteSettingsForm } from '@/components/admin/settings/SiteSettingsForm';
import { EmptyState } from '@/components/ui/EmptyState';

export default async function AdminSettingsPage() {
  const [profile, settings] = await Promise.all([getSiteProfile(), getSiteSettings()]);

  if (!profile || !settings) {
    return (
      <EmptyState
        title="Settings could not be loaded"
        description="Make sure the schema.sql seed rows for site_profile and site_settings were inserted."
      />
    );
  }

  return (
    <div className="flex flex-col gap-10">
      <div>
        <h1 className="font-display text-2xl font-bold text-ink-950">Website Settings</h1>
        <p className="mt-1 text-sm text-ink-900/50">Manage your public profile content and site-wide configuration.</p>
      </div>

      <section>
        <h2 className="font-display text-base font-semibold text-ink-950">Profile Images</h2>
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <ProfileImageForm profileId={profile.id} field="avatar_url" label="Avatar (used in navbar &amp; hero)" currentUrl={profile.avatar_url} />
          <ProfileImageForm profileId={profile.id} field="hero_image_url" label="Hero background image" currentUrl={profile.hero_image_url} />
        </div>
      </section>

      <section>
        <h2 className="font-display text-base font-semibold text-ink-950">About Page Content</h2>
        <div className="mt-4 rounded-xl2 border border-ink-900/8 bg-white p-6 shadow-card">
          <ProfileSettingsForm profile={profile} />
        </div>
      </section>

      <section>
        <h2 className="font-display text-base font-semibold text-ink-950">Site Configuration</h2>
        <div className="mt-4 rounded-xl2 border border-ink-900/8 bg-white p-6 shadow-card">
          <SiteSettingsForm settings={settings} />
        </div>
        <p className="mt-2 text-xs text-ink-900/40">
          Note: &quot;Maintenance mode&quot; is stored here for Phase 2 use but is not yet enforced anywhere in Phase 1 — it does not currently hide the site.
        </p>
      </section>
    </div>
  );
}
