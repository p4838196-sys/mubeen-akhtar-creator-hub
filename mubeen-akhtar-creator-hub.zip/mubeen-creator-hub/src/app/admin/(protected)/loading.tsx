export default function AdminLoading() {
  return (
    <div className="flex flex-col gap-4">
      <div className="skeleton h-8 w-48" />
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        {Array.from({ length: 4 }).map((_, i) => <div key={i} className="skeleton h-24 w-full" />)}
      </div>
    </div>
  );
}
