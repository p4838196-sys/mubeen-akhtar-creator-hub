import { redirect } from 'next/navigation';
import { getCurrentAdminUser } from '@/lib/data/auth';
import { AdminSidebar } from '@/components/admin/AdminSidebar';

export const metadata = { robots: { index: false, follow: false } };

export default async function AdminProtectedLayout({ children }: { children: React.ReactNode }) {
  // Second, authoritative check beyond middleware: middleware only confirms
  // a session exists, not that the session belongs to an admin. This is
  // the real gate — combined with the is_admin() RLS policies on every
  // table, a non-admin session can neither view this layout nor read/write
  // protected data even if they somehow reached this far.
  const admin = await getCurrentAdminUser();
  if (!admin) {
    redirect('/admin/login');
  }

  return (
    <div className="flex min-h-[calc(100vh-4rem)] flex-col lg:flex-row">
      <AdminSidebar email={admin.email} />
      <main className="flex-1 bg-ink-900/[0.02] p-4 sm:p-6 lg:p-10">{children}</main>
    </div>
  );
}
