import { createClient } from '@/lib/supabase/server';
import { summarizeRatings } from '@/lib/utils/ratings';
import { RatingsOverview } from '@/components/admin/ratings/RatingsOverview';

export default async function AdminRatingsPage() {
  const supabase = await createClient();
  const [photoRatings, videoRatings] = await Promise.all([
    supabase.from('ratings').select('stars').eq('target_type', 'photo'),
    supabase.from('ratings').select('stars').eq('target_type', 'video'),
  ]);

  const photoSummary = summarizeRatings(photoRatings.data ?? []);
  const videoSummary = summarizeRatings(videoRatings.data ?? []);

  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-ink-950">Ratings</h1>
      <p className="mt-1 text-sm text-ink-900/50">Aggregate rating breakdown across all photos and videos.</p>
      <div className="mt-6">
        <RatingsOverview photoSummary={photoSummary} videoSummary={videoSummary} />
      </div>
    </div>
  );
}
