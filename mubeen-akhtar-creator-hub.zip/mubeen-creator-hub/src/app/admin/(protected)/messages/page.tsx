import { getAllContactMessagesAdmin } from '@/lib/data/messages';
import { MessagesList } from '@/components/admin/messages/MessagesList';

export default async function AdminMessagesPage() {
  const messages = await getAllContactMessagesAdmin();

  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-ink-950">Contact Messages</h1>
      <p className="mt-1 text-sm text-ink-900/50">Private inbox — never shown publicly.</p>
      <div className="mt-6">
        <MessagesList messages={messages} />
      </div>
    </div>
  );
}
