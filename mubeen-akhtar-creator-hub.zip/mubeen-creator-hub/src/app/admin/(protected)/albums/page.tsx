import { createClient } from '@/lib/supabase/server';
import { AlbumsManager } from '@/components/admin/albums/AlbumsManager';
import type { Album } from '@/lib/types/database.types';

async function getAllAlbumsAdmin(): Promise<Album[]> {
  const supabase = await createClient();
  const { data, error } = await supabase.from('albums').select('*').order('display_order', { ascending: true });
  if (error) {
    console.error('getAllAlbumsAdmin error', error.message);
    return [];
  }
  return data ?? [];
}

export default async function AdminAlbumsPage() {
  const albums = await getAllAlbumsAdmin();

  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-ink-950">Albums</h1>
      <p className="mt-1 text-sm text-ink-900/50">Organize photos into albums. Inactive albums are hidden from the public site.</p>
      <div className="mt-6">
        <AlbumsManager albums={albums} />
      </div>
    </div>
  );
}
