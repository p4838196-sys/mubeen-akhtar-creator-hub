import { getAllReviewsAdmin } from '@/lib/data/reviews';
import { ReviewsModerationList } from '@/components/admin/reviews/ReviewsModerationList';

export default async function AdminReviewsPage() {
  const reviews = await getAllReviewsAdmin();

  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-ink-950">Reviews</h1>
      <p className="mt-1 text-sm text-ink-900/50">Approve, hide, feature or delete submitted reviews.</p>
      <div className="mt-6">
        <ReviewsModerationList reviews={reviews} />
      </div>
    </div>
  );
}
