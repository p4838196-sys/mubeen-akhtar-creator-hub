import { createClient } from '@/lib/supabase/server';
import { VideosManager } from '@/components/admin/videos/VideosManager';
import type { Video } from '@/lib/types/database.types';

async function getAllVideosAdmin(): Promise<Video[]> {
  const supabase = await createClient();
  const { data, error } = await supabase.from('videos').select('*').order('created_at', { ascending: false });
  if (error) {
    console.error('getAllVideosAdmin error', error.message);
    return [];
  }
  return data ?? [];
}

export default async function AdminVideosPage() {
  const videos = await getAllVideosAdmin();

  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-ink-950">Videos</h1>
      <p className="mt-1 text-sm text-ink-900/50">Add hosted uploads or external links (YouTube, TikTok, etc.).</p>
      <div className="mt-6">
        <VideosManager videos={videos} />
      </div>
    </div>
  );
}
