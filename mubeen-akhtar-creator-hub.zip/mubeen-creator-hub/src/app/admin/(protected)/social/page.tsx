import { getAllSocialAccountsAdmin } from '@/lib/data/social';
import { SocialAccountsManager } from '@/components/admin/social/SocialAccountsManager';

export default async function AdminSocialPage() {
  const accounts = await getAllSocialAccountsAdmin();

  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-ink-950">Social Accounts</h1>
      <p className="mt-1 text-sm text-ink-900/50">Manage the official profile links shown on the Social Hub page.</p>
      <div className="mt-6">
        <SocialAccountsManager accounts={accounts} />
      </div>
    </div>
  );
}
