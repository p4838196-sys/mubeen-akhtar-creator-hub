import { createClient } from '@/lib/supabase/server';
import { getPublicStorageUrl } from '@/lib/supabase/storage';
import { getActiveAlbums } from '@/lib/data/photos';
import { PhotosManager } from '@/components/admin/photos/PhotosManager';
import type { Photo } from '@/lib/types/database.types';

async function getAllPhotosAdmin() {
  const supabase = await createClient();
  const { data, error } = await supabase.from('photos').select('*').order('created_at', { ascending: false });
  if (error) {
    console.error('getAllPhotosAdmin error', error.message);
    return [];
  }
  return Promise.all(
    (data ?? []).map(async (p) => ({ ...(p as Photo), url: await getPublicStorageUrl('photos', (p as Photo).storage_path) }))
  );
}

export default async function AdminPhotosPage() {
  const [photos, albums] = await Promise.all([getAllPhotosAdmin(), getActiveAlbums()]);

  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-ink-950">Photos</h1>
      <p className="mt-1 text-sm text-ink-900/50">Upload and manage every photo in the gallery.</p>
      <div className="mt-6">
        <PhotosManager photos={photos} albums={albums} />
      </div>
    </div>
  );
}
