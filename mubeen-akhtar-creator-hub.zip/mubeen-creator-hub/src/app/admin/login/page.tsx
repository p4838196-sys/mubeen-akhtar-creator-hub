import type { Metadata } from 'next';
import { Suspense } from 'react';
import { LoginForm } from '@/components/admin/LoginForm';

export const metadata: Metadata = { title: 'Admin Login', robots: { index: false, follow: false } };

export default function AdminLoginPage() {
  return (
    <div className="flex min-h-[calc(100vh-4rem)] items-center justify-center bg-ink-900/[0.02] px-4 py-16">
      <div className="w-full max-w-sm rounded-xl2 border border-ink-900/8 bg-white p-8 shadow-card">
        <h1 className="font-display text-xl font-bold text-ink-950">Admin Sign In</h1>
        <p className="mt-1 text-sm text-ink-900/50">Restricted area — authorized admins only.</p>

        <div className="mt-6">
          <Suspense fallback={null}>
            <LoginForm />
          </Suspense>
        </div>
      </div>
    </div>
  );
}
