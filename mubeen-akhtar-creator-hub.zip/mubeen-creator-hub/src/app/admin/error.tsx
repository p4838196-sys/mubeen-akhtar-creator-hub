'use client';

import { useEffect } from 'react';

export default function AdminError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    console.error('Admin error boundary:', error);
  }, [error]);

  return (
    <div className="flex min-h-[50vh] flex-col items-center justify-center p-8 text-center">
      <p className="font-display text-xl font-bold text-ink-950">Something went wrong</p>
      <p className="mt-2 max-w-md text-sm text-ink-900/60">{error.message || 'An unexpected error occurred.'}</p>
      <button onClick={reset} className="mt-6 rounded-full bg-ink-950 px-5 py-2.5 text-sm font-semibold text-white hover:bg-ink-800">
        Try again
      </button>
    </div>
  );
}
