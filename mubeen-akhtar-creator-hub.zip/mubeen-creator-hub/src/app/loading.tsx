import { GridSkeleton } from '@/components/ui/Skeleton';

export default function Loading() {
  return (
    <div className="container-page py-16">
      <GridSkeleton count={8} />
    </div>
  );
}
