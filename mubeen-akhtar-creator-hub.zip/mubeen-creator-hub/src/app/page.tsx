import { getSiteProfile } from '@/lib/data/profile';
import { getActiveSocialAccounts } from '@/lib/data/social';
import { getFeaturedPhotos, getPublishedPhotos } from '@/lib/data/photos';
import { getFeaturedVideos, getPublishedVideos } from '@/lib/data/videos';
import { getAudienceRatingSummary } from '@/lib/data/reviews';
import { Hero } from '@/components/home/Hero';
import { FeaturedContent } from '@/components/home/FeaturedContent';
import { LatestPhotos } from '@/components/home/LatestPhotos';
import { LatestVideos } from '@/components/home/LatestVideos';
import { SocialStrip } from '@/components/home/SocialStrip';
import { RatingsSection } from '@/components/home/RatingsSection';
import { AIZoneTeaser } from '@/components/home/AIZoneTeaser';

export default async function HomePage() {
  const [profile, socials, featuredPhotos, featuredVideos, latestPhotos, latestVideos, ratingSummary] = await Promise.all([
    getSiteProfile(),
    getActiveSocialAccounts(),
    getFeaturedPhotos(1),
    getFeaturedVideos(1),
    getPublishedPhotos({ page: 1 }).then((r) => r.photos.slice(0, 6)),
    getPublishedVideos({ page: 1 }).then((r) => r.videos.slice(0, 4)),
    getAudienceRatingSummary(),
  ]);

  const featuredPhoto = featuredPhotos[0] ?? null;
  const featuredVideo = featuredVideos[0] ?? null;
  const heroFeatured = featuredPhoto ?? featuredVideo ?? latestPhotos[0] ?? latestVideos[0] ?? null;

  return (
    <>
      <Hero profile={profile} socials={socials} featured={heroFeatured} />
      <FeaturedContent photo={featuredPhoto} video={featuredVideo} />
      <LatestPhotos photos={latestPhotos} />
      <LatestVideos videos={latestVideos} />
      <SocialStrip socials={socials} />
      <RatingsSection summary={ratingSummary} />
      <AIZoneTeaser />
    </>
  );
}
