import Link from 'next/link';

export default function NotFound() {
  return (
    <div className="container-page flex min-h-[60vh] flex-col items-center justify-center text-center">
      <p className="font-display text-6xl font-bold text-ink-950">404</p>
      <p className="mt-2 text-base text-ink-900/60">This page could not be found.</p>
      <Link href="/" className="mt-6 rounded-full bg-ink-950 px-5 py-2.5 text-sm font-semibold text-white hover:bg-ink-800">
        Back to Home
      </Link>
    </div>
  );
}
