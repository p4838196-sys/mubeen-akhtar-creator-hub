import Image from 'next/image';
import type { Metadata } from 'next';
import { getSiteProfile } from '@/lib/data/profile';
import { SectionHeading } from '@/components/ui/SectionHeading';
import { EmptyState } from '@/components/ui/EmptyState';

export const metadata: Metadata = { title: 'About Me' };

export default async function AboutPage() {
  const profile = await getSiteProfile();

  if (!profile || (!profile.bio && !profile.journey && !profile.future_vision)) {
    return (
      <div className="container-page py-16">
        <SectionHeading eyebrow="About" title="About Me" />
        <div className="mt-8">
          <EmptyState
            title="This page hasn't been set up yet"
            description="Add a bio, journey and vision from the admin dashboard under Website Settings."
          />
        </div>
      </div>
    );
  }

  return (
    <div className="container-page py-14 sm:py-20">
      <div className="grid gap-10 lg:grid-cols-[280px_1fr] lg:gap-14">
        <div>
          <div className="relative aspect-square w-full max-w-xs overflow-hidden rounded-xl2 bg-ink-900/5">
            {profile.avatar_url ? (
              <Image src={profile.avatar_url} alt={profile.display_name} fill sizes="320px" className="object-cover" />
            ) : (
              <div className="flex h-full items-center justify-center text-4xl font-semibold text-ink-900/20">
                {profile.display_name.charAt(0)}
              </div>
            )}
          </div>
          <h1 className="mt-5 font-display text-2xl font-bold text-ink-950">{profile.display_name}</h1>
          {profile.tagline && <p className="mt-1 text-sm text-ink-900/55">{profile.tagline}</p>}

          {profile.skills.length > 0 && (
            <div className="mt-6">
              <p className="text-xs font-semibold uppercase tracking-widest text-ink-900/40">Skills</p>
              <div className="mt-2 flex flex-wrap gap-2">
                {profile.skills.map((skill) => (
                  <span key={skill} className="rounded-full bg-ink-900/5 px-3 py-1 text-xs font-medium text-ink-900/70">
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          )}

          {profile.interests.length > 0 && (
            <div className="mt-6">
              <p className="text-xs font-semibold uppercase tracking-widest text-ink-900/40">Interests</p>
              <div className="mt-2 flex flex-wrap gap-2">
                {profile.interests.map((interest) => (
                  <span key={interest} className="rounded-full border border-ink-900/10 px-3 py-1 text-xs font-medium text-ink-900/60">
                    {interest}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="flex flex-col gap-10">
          {profile.bio && (
            <section>
              <h2 className="font-display text-xl font-semibold text-ink-950">Biography</h2>
              <p className="mt-3 whitespace-pre-line text-base leading-relaxed text-ink-900/70">{profile.bio}</p>
            </section>
          )}
          {profile.journey && (
            <section>
              <h2 className="font-display text-xl font-semibold text-ink-950">Creator Journey</h2>
              <p className="mt-3 whitespace-pre-line text-base leading-relaxed text-ink-900/70">{profile.journey}</p>
            </section>
          )}
          {profile.future_vision && (
            <section>
              <h2 className="font-display text-xl font-semibold text-ink-950">Future Vision</h2>
              <p className="mt-3 whitespace-pre-line text-base leading-relaxed text-ink-900/70">{profile.future_vision}</p>
            </section>
          )}
        </div>
      </div>
    </div>
  );
}
