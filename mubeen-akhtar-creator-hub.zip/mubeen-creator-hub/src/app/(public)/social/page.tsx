import type { Metadata } from 'next';
import { getActiveSocialAccounts } from '@/lib/data/social';
import { SocialIcon, platformLabels } from '@/components/social/SocialIcon';
import { formatFollowerCount } from '@/lib/utils/format';
import { EmptyState } from '@/components/ui/EmptyState';

export const metadata: Metadata = { title: 'Social Hub' };

export default async function SocialHubPage() {
  const socials = await getActiveSocialAccounts();

  return (
    <div className="container-page py-14 sm:py-20">
      <div className="max-w-2xl">
        <p className="text-xs font-semibold uppercase tracking-widest text-brand-600">Connect</p>
        <h1 className="mt-1 font-display text-3xl font-bold text-ink-950 sm:text-4xl">Social Hub</h1>
        <p className="mt-3 text-base text-ink-900/60">
          Every official channel, in one place. Follow along for new photos, videos and updates.
        </p>
      </div>

      <div className="mt-10">
        {socials.length === 0 ? (
          <EmptyState title="No social accounts added yet" description="Accounts added from the admin dashboard will appear here." />
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {socials.map((s) => (
              <a
                key={s.id}
                href={s.profile_url}
                target="_blank"
                rel="noopener noreferrer"
                className="group flex flex-col gap-4 rounded-xl2 border border-ink-900/8 p-6 shadow-card transition-all hover:-translate-y-0.5 hover:border-brand-300 hover:shadow-lg"
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-ink-950 text-white transition-colors group-hover:bg-brand-500">
                    <SocialIcon platform={s.platform} className="h-5.5 w-5.5" />
                  </div>
                  <div>
                    <p className="font-display text-base font-semibold text-ink-950">{platformLabels[s.platform]}</p>
                    <p className="text-sm text-ink-900/50">@{s.username}</p>
                  </div>
                </div>
                <div className="flex items-center justify-between text-sm">
                  {s.follower_count !== null ? (
                    <span className="font-medium text-ink-900/60">{formatFollowerCount(s.follower_count)} followers</span>
                  ) : (
                    <span />
                  )}
                  <span className="font-semibold text-brand-600">Visit &rarr;</span>
                </div>
              </a>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
