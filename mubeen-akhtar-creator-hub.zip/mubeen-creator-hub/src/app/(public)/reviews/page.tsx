import type { Metadata } from 'next';
import { getApprovedReviews, getAudienceRatingSummary } from '@/lib/data/reviews';
import { ReviewForm } from '@/components/reviews/ReviewForm';
import { ReviewList } from '@/components/reviews/ReviewList';
import { StarDisplay } from '@/components/ui/StarRating';

export const metadata: Metadata = { title: 'Ratings & Reviews' };

export default async function ReviewsPage() {
  const [reviews, summary] = await Promise.all([getApprovedReviews(), getAudienceRatingSummary()]);

  return (
    <div className="container-page py-14 sm:py-20">
      <div className="max-w-2xl">
        <p className="text-xs font-semibold uppercase tracking-widest text-brand-600">Feedback</p>
        <h1 className="mt-1 font-display text-3xl font-bold text-ink-950 sm:text-4xl">Ratings &amp; Reviews</h1>
        <p className="mt-3 text-base text-ink-900/60">See what people are saying, and share your own experience.</p>

        <div className="mt-6 flex items-center gap-3">
          {summary.count > 0 ? (
            <>
              <span className="font-display text-3xl font-bold text-ink-950">{summary.average?.toFixed(1)}</span>
              <div>
                <StarDisplay value={summary.average ?? 0} size="md" />
                <p className="text-xs text-ink-900/45">{summary.count} review{summary.count !== 1 ? 's' : ''}</p>
              </div>
            </>
          ) : (
            <p className="text-sm text-ink-900/40">No ratings yet</p>
          )}
        </div>
      </div>

      <div className="mt-12 grid gap-10 lg:grid-cols-[1fr_360px]">
        <ReviewList reviews={reviews} />
        <div>
          <ReviewForm />
        </div>
      </div>
    </div>
  );
}
