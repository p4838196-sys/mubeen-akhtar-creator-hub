import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import Link from 'next/link';
import { getVideoById } from '@/lib/data/videos';
import { getRatingSummary, getLikeCount } from '@/lib/data/ratings';
import { VideoPlayer } from '@/components/videos/VideoPlayer';
import { ContentEngagement } from '@/components/shared/ContentEngagement';
import { formatDate } from '@/lib/utils/format';

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }): Promise<Metadata> {
  const { id } = await params;
  const video = await getVideoById(id);
  return { title: video?.title ?? 'Video' };
}

export default async function VideoDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const video = await getVideoById(id);
  if (!video) notFound();

  const [summary, likeCount] = await Promise.all([getRatingSummary('video', video.id), getLikeCount('video', video.id)]);
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || '';

  return (
    <div className="container-page py-10 sm:py-16">
      <Link href="/videos" className="text-sm font-medium text-ink-900/50 hover:text-ink-900">&larr; Back to videos</Link>

      <div className="mt-4 overflow-hidden rounded-xl2 bg-black">
        <div className="aspect-video w-full">
          <VideoPlayer video={video} />
        </div>
      </div>

      <div className="mt-6 max-w-3xl">
        {video.category && <p className="text-xs font-semibold uppercase tracking-wide text-brand-600">{video.category}</p>}
        <h1 className="mt-1 font-display text-2xl font-bold text-ink-950 sm:text-3xl">{video.title}</h1>
        <p className="mt-1 text-xs text-ink-900/40">{formatDate(video.created_at)}</p>
        {video.description && <p className="mt-4 whitespace-pre-line text-base text-ink-900/70">{video.description}</p>}

        <div className="mt-6">
          <ContentEngagement
            targetType="video"
            targetId={video.id}
            initialSummary={summary}
            initialLikeCount={likeCount}
            shareUrl={`${siteUrl}/videos/${video.id}`}
            shareTitle={video.title}
          />
        </div>
      </div>
    </div>
  );
}
