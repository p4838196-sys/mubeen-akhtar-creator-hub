import type { Metadata } from 'next';
import Link from 'next/link';
import { getPublishedVideos } from '@/lib/data/videos';
import { VideoCard } from '@/components/videos/VideoCard';
import { EmptyState } from '@/components/ui/EmptyState';
import { cn } from '@/lib/utils/cn';

export const metadata: Metadata = { title: 'Videos' };

export default async function VideosPage({
  searchParams,
}: {
  searchParams: Promise<{ category?: string; page?: string }>;
}) {
  const params = await searchParams;
  const page = params.page ? Number(params.page) : 1;
  const { videos, total, pageSize, categories } = await getPublishedVideos({ category: params.category, page });
  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  return (
    <div className="container-page py-14 sm:py-20">
      <div className="max-w-2xl">
        <p className="text-xs font-semibold uppercase tracking-widest text-brand-600">Watch</p>
        <h1 className="mt-1 font-display text-3xl font-bold text-ink-950 sm:text-4xl">Videos</h1>
        <p className="mt-3 text-base text-ink-900/60">Uploaded videos and external links, all in one feed.</p>
      </div>

      {categories.length > 0 && (
        <div className="mt-8 flex flex-wrap gap-2 overflow-x-auto">
          <Link
            href="/videos"
            className={cn(
              'whitespace-nowrap rounded-full px-4 py-2 text-sm font-medium transition-colors',
              !params.category ? 'bg-ink-950 text-white' : 'bg-ink-900/5 text-ink-900/70 hover:bg-ink-900/10'
            )}
          >
            All Categories
          </Link>
          {categories.map((cat) => (
            <Link
              key={cat}
              href={`/videos?category=${encodeURIComponent(cat)}`}
              className={cn(
                'whitespace-nowrap rounded-full px-4 py-2 text-sm font-medium transition-colors',
                params.category === cat ? 'bg-ink-950 text-white' : 'bg-ink-900/5 text-ink-900/70 hover:bg-ink-900/10'
              )}
            >
              {cat}
            </Link>
          ))}
        </div>
      )}

      <div className="mt-8">
        {videos.length === 0 ? (
          <EmptyState title="No videos yet" description="New videos will appear here once uploaded." />
        ) : (
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {videos.map((video) => <VideoCard key={video.id} video={video} />)}
          </div>
        )}
      </div>

      {totalPages > 1 && (
        <div className="mt-10 flex items-center justify-center gap-2">
          {Array.from({ length: totalPages }).map((_, i) => {
            const p = i + 1;
            const href = `/videos?${params.category ? `category=${encodeURIComponent(params.category)}&` : ''}page=${p}`;
            return (
              <Link
                key={p}
                href={href}
                className={cn(
                  'flex h-9 w-9 items-center justify-center rounded-full text-sm font-medium',
                  p === page ? 'bg-ink-950 text-white' : 'bg-ink-900/5 text-ink-900/70 hover:bg-ink-900/10'
                )}
              >
                {p}
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
