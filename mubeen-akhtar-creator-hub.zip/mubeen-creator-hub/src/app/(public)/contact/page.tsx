import type { Metadata } from 'next';
import { ContactForm } from '@/components/contact/ContactForm';
import { getSiteSettings } from '@/lib/data/settings';

export const metadata: Metadata = { title: 'Contact' };

export default async function ContactPage() {
  const settings = await getSiteSettings();

  return (
    <div className="container-page py-14 sm:py-20">
      <div className="mx-auto max-w-2xl text-center">
        <p className="text-xs font-semibold uppercase tracking-widest text-brand-600">Get in Touch</p>
        <h1 className="mt-1 font-display text-3xl font-bold text-ink-950 sm:text-4xl">Contact</h1>
        <p className="mt-3 text-base text-ink-900/60">
          Have a question, collaboration idea, or just want to say hi? Send a message below.
          {settings?.contact_email && (
            <>
              {' '}Or email directly at{' '}
              <a href={`mailto:${settings.contact_email}`} className="font-medium text-brand-600 hover:underline">
                {settings.contact_email}
              </a>
              .
            </>
          )}
        </p>
      </div>

      <div className="mx-auto mt-10 max-w-xl">
        <ContactForm />
      </div>
    </div>
  );
}
