import type { Metadata } from 'next';
import Link from 'next/link';
import { getActiveAlbums, getPublishedPhotos } from '@/lib/data/photos';
import { getRatingSummariesBulk, getLikeCountsBulk } from '@/lib/data/ratings';
import { PhotoGrid } from '@/components/photos/PhotoGrid';
import { cn } from '@/lib/utils/cn';

export const metadata: Metadata = { title: 'Photos' };

export default async function PhotosPage({
  searchParams,
}: {
  searchParams: Promise<{ album?: string; page?: string }>;
}) {
  const params = await searchParams;
  const page = params.page ? Number(params.page) : 1;

  const [albums, { photos, total, pageSize }] = await Promise.all([
    getActiveAlbums(),
    getPublishedPhotos({ albumSlug: params.album, page }),
  ]);

  const photoIds = photos.map((p) => p.id);
  const [ratingSummaries, likeCounts] = await Promise.all([
    getRatingSummariesBulk('photo', photoIds),
    getLikeCountsBulk('photo', photoIds),
  ]);

  const photosWithEngagement = photos.map((p) => ({
    ...p,
    ratingSummary: ratingSummaries[p.id] ?? { average: null, count: 0, distribution: { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 } },
    likeCount: likeCounts[p.id] ?? 0,
  }));

  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  return (
    <div className="container-page py-14 sm:py-20">
      <div className="max-w-2xl">
        <p className="text-xs font-semibold uppercase tracking-widest text-brand-600">Gallery</p>
        <h1 className="mt-1 font-display text-3xl font-bold text-ink-950 sm:text-4xl">Photos</h1>
        <p className="mt-3 text-base text-ink-900/60">Browse albums, view full-screen, rate and share your favorites.</p>
      </div>

      {albums.length > 0 && (
        <div className="mt-8 flex flex-wrap gap-2 overflow-x-auto">
          <Link
            href="/photos"
            className={cn(
              'whitespace-nowrap rounded-full px-4 py-2 text-sm font-medium transition-colors',
              !params.album ? 'bg-ink-950 text-white' : 'bg-ink-900/5 text-ink-900/70 hover:bg-ink-900/10'
            )}
          >
            All Photos
          </Link>
          {albums.map((album) => (
            <Link
              key={album.id}
              href={`/photos?album=${album.slug}`}
              className={cn(
                'whitespace-nowrap rounded-full px-4 py-2 text-sm font-medium transition-colors',
                params.album === album.slug ? 'bg-ink-950 text-white' : 'bg-ink-900/5 text-ink-900/70 hover:bg-ink-900/10'
              )}
            >
              {album.title}
            </Link>
          ))}
        </div>
      )}

      <div className="mt-8">
        <PhotoGrid photos={photosWithEngagement} />
      </div>

      {totalPages > 1 && (
        <div className="mt-10 flex items-center justify-center gap-2">
          {Array.from({ length: totalPages }).map((_, i) => {
            const p = i + 1;
            const href = `/photos?${params.album ? `album=${params.album}&` : ''}page=${p}`;
            return (
              <Link
                key={p}
                href={href}
                className={cn(
                  'flex h-9 w-9 items-center justify-center rounded-full text-sm font-medium',
                  p === page ? 'bg-ink-950 text-white' : 'bg-ink-900/5 text-ink-900/70 hover:bg-ink-900/10'
                )}
              >
                {p}
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
