import type { Metadata } from 'next';
import { Card } from '@/components/ui/Card';

export const metadata: Metadata = { title: 'AI Zone' };

const creatorTools = [
  { name: 'Caption Generator', description: 'Generate engaging captions for photos and videos in seconds.' },
  { name: 'Video Idea Generator', description: 'Get fresh content ideas tailored to your niche and audience.' },
  { name: 'Script Generator', description: 'Draft video scripts with hooks, structure and a clear call-to-action.' },
  { name: 'Prompt Generator', description: 'Build effective prompts for image, video and text AI tools.' },
  { name: 'Content Planner', description: 'Plan a posting calendar across all your platforms.' },
];

const studentTools = [
  { name: 'Study Assistant', description: 'Ask questions and get clear, structured explanations while you study.' },
  { name: 'Quiz Generator', description: 'Turn any topic or notes into a self-test quiz.' },
  { name: 'Notes Generator', description: 'Summarize long material into clean, organized notes.' },
  { name: 'Presentation Helper', description: 'Outline and structure slide decks for class presentations.' },
  { name: 'Explanation Assistant', description: 'Break down difficult concepts into simple, digestible steps.' },
];

function ToolCard({ name, description }: { name: string; description: string }) {
  return (
    <Card className="p-5">
      <div className="flex items-center justify-between">
        <h3 className="font-display text-base font-semibold text-ink-950">{name}</h3>
        <span className="rounded-full bg-ink-900/5 px-2.5 py-1 text-[11px] font-semibold text-ink-900/50">Planned</span>
      </div>
      <p className="mt-2 text-sm text-ink-900/60">{description}</p>
    </Card>
  );
}

export default function AIZonePage() {
  return (
    <div className="container-page py-14 sm:py-20">
      <div className="overflow-hidden rounded-xl2 bg-gradient-to-br from-ink-950 to-ink-800 p-8 text-white sm:p-14">
        <p className="text-xs font-semibold uppercase tracking-widest text-brand-400">Coming Soon</p>
        <h1 className="mt-2 max-w-2xl font-display text-3xl font-bold sm:text-4xl">AI Creator &amp; Student Zone</h1>
        <p className="mt-4 max-w-2xl text-base text-white/60 sm:text-lg">
          A dedicated space combining practical AI tools for creators and students — from caption and script
          generation to study assistants and quiz generators. This section is being built as Phase 3 of the
          platform; tools will be added here once ready, without needing a site rebuild.
        </p>
      </div>

      <div className="mt-14">
        <h2 className="font-display text-xl font-semibold text-ink-950">Creator Tools</h2>
        <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {creatorTools.map((tool) => <ToolCard key={tool.name} {...tool} />)}
        </div>
      </div>

      <div className="mt-14">
        <h2 className="font-display text-xl font-semibold text-ink-950">Student Tools</h2>
        <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {studentTools.map((tool) => <ToolCard key={tool.name} {...tool} />)}
        </div>
      </div>

      <div className="mt-14 rounded-xl2 border border-dashed border-ink-900/15 p-6 text-center">
        <p className="text-sm text-ink-900/50">
          Want to be notified when AI tools launch? Reach out via the{' '}
          <a href="/contact" className="font-medium text-brand-600 hover:underline">Contact page</a>.
        </p>
      </div>
    </div>
  );
}
