'use client';

import { useEffect } from 'react';

export default function Error({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    console.error('App error boundary:', error);
  }, [error]);

  return (
    <div className="container-page flex min-h-[60vh] flex-col items-center justify-center text-center">
      <p className="font-display text-2xl font-bold text-ink-950">Something went wrong</p>
      <p className="mt-2 max-w-md text-sm text-ink-900/60">
        An unexpected error occurred while loading this page. You can try again below.
      </p>
      <button onClick={reset} className="mt-6 rounded-full bg-ink-950 px-5 py-2.5 text-sm font-semibold text-white hover:bg-ink-800">
        Try again
      </button>
    </div>
  );
}
