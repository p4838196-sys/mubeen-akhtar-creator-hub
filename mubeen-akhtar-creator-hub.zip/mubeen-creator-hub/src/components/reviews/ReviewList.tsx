import { StarDisplay } from '@/components/ui/StarRating';
import { EmptyState } from '@/components/ui/EmptyState';
import { timeAgo } from '@/lib/utils/format';
import type { Review } from '@/lib/types/database.types';

export function ReviewList({ reviews }: { reviews: Review[] }) {
  if (reviews.length === 0) {
    return <EmptyState title="No reviews yet" description="Be the first to leave a review!" />;
  }

  return (
    <div className="grid gap-4 sm:grid-cols-2">
      {reviews.map((review) => (
        <div key={review.id} className="flex flex-col gap-3 rounded-xl2 border border-ink-900/8 bg-white p-5 shadow-card">
          <div className="flex items-center justify-between">
            <StarDisplay value={review.stars} size="sm" />
            {review.is_featured && (
              <span className="rounded-full bg-brand-50 px-2 py-0.5 text-[11px] font-semibold text-brand-600">Featured</span>
            )}
          </div>
          <p className="text-sm leading-relaxed text-ink-900/75">&ldquo;{review.message}&rdquo;</p>
          <div className="mt-auto flex items-center justify-between text-xs text-ink-900/40">
            <span className="font-medium text-ink-900/60">{review.display_name}</span>
            <span>{timeAgo(review.created_at)}</span>
          </div>
        </div>
      ))}
    </div>
  );
}
