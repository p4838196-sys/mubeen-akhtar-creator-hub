'use client';

import { useActionState, useEffect, useState } from 'react';
import { StarPicker } from '@/components/ui/StarRating';
import { submitReview } from '@/lib/actions/public';
import { getOrCreateSessionId } from '@/lib/utils/session';

const initialState = { success: false, message: '' };

export function ReviewForm() {
  const [state, formAction, pending] = useActionState(submitReview, initialState);
  const [stars, setStars] = useState(0);
  const [sessionId, setSessionId] = useState('');

  useEffect(() => {
    setSessionId(getOrCreateSessionId());
  }, []);

  useEffect(() => {
    if (state.success) setStars(0);
  }, [state.success]);

  return (
    <form action={formAction} className="flex flex-col gap-4 rounded-xl2 border border-ink-900/8 bg-white p-6 shadow-card">
      <h2 className="font-display text-lg font-semibold text-ink-950">Leave a Review</h2>

      <input type="hidden" name="session_id" value={sessionId} />
      {/* Honeypot — hidden from real users via CSS, bots tend to fill every field */}
      <input type="text" name="company" tabIndex={-1} autoComplete="off" className="hidden" aria-hidden="true" />

      <div>
        <label htmlFor="display_name" className="text-sm font-medium text-ink-900">Your name</label>
        <input
          id="display_name"
          name="display_name"
          required
          maxLength={80}
          className="mt-1.5 w-full rounded-lg border border-ink-900/15 px-3.5 py-2.5 text-sm outline-none focus:border-brand-500"
          placeholder="Jane Doe"
        />
      </div>

      <div>
        <p className="text-sm font-medium text-ink-900">Rating</p>
        <div className="mt-1.5">
          <StarPicker value={stars} onChange={setStars} name="stars" size="md" />
        </div>
      </div>

      <div>
        <label htmlFor="message" className="text-sm font-medium text-ink-900">Your review</label>
        <textarea
          id="message"
          name="message"
          required
          minLength={5}
          maxLength={1000}
          rows={4}
          className="mt-1.5 w-full resize-none rounded-lg border border-ink-900/15 px-3.5 py-2.5 text-sm outline-none focus:border-brand-500"
          placeholder="Share your experience..."
        />
      </div>

      {state.message && (
        <p className={state.success ? 'text-sm text-green-600' : 'text-sm text-red-600'}>{state.message}</p>
      )}

      <button
        type="submit"
        disabled={pending || stars === 0 || !sessionId}
        className="rounded-full bg-ink-950 px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-ink-800 disabled:opacity-50"
      >
        {pending ? 'Submitting…' : 'Submit Review'}
      </button>
      <p className="text-xs text-ink-900/40">Reviews are moderated and may take a moment to appear publicly.</p>
    </form>
  );
}
