'use client';

import { useState, useTransition } from 'react';
import { StarDisplay, StarPicker } from '@/components/ui/StarRating';
import { getOrCreateSessionId } from '@/lib/utils/session';
import { submitRating, submitLike } from '@/lib/actions/public';
import type { RatingSummary, RatingTargetType } from '@/lib/types/database.types';

export function ContentEngagement({
  targetType,
  targetId,
  initialSummary,
  initialLikeCount,
  shareUrl,
  shareTitle,
}: {
  targetType: RatingTargetType;
  targetId: string;
  initialSummary: RatingSummary;
  initialLikeCount: number;
  shareUrl: string;
  shareTitle: string;
}) {
  const [summary, setSummary] = useState(initialSummary);
  const [likeCount, setLikeCount] = useState(initialLikeCount);
  const [liked, setLiked] = useState(false);
  const [myRating, setMyRating] = useState(0);
  const [pending, startTransition] = useTransition();
  const [feedback, setFeedback] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  function handleRate(stars: number) {
    setMyRating(stars);
    startTransition(async () => {
      const sessionId = getOrCreateSessionId();
      const result = await submitRating({ target_type: targetType, target_id: targetId, stars, session_id: sessionId });
      setFeedback(result.success ? 'Thanks for rating!' : result.message);
    });
  }

  function handleLike() {
    if (liked) return;
    setLiked(true);
    setLikeCount((c) => c + 1);
    startTransition(async () => {
      const sessionId = getOrCreateSessionId();
      const result = await submitLike({ target_type: targetType, target_id: targetId, session_id: sessionId });
      if (!result.success) {
        setLiked(false);
        setLikeCount((c) => Math.max(0, c - 1));
      }
    });
  }

  async function handleShare() {
    if (typeof navigator !== 'undefined' && 'share' in navigator) {
      try {
        await navigator.share({ title: shareTitle, url: shareUrl });
        return;
      } catch {
        // user cancelled — fall through to copy
      }
    }
    await navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <div className="flex flex-col gap-4 border-t border-ink-900/8 pt-4">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          {summary.count > 0 ? (
            <div className="flex items-center gap-2">
              <StarDisplay value={summary.average ?? 0} size="md" />
              <span className="text-sm text-ink-900/60">
                {summary.average?.toFixed(1)} · {summary.count} rating{summary.count !== 1 ? 's' : ''}
              </span>
            </div>
          ) : (
            <p className="text-sm text-ink-900/40">No ratings yet</p>
          )}
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleLike}
            disabled={liked}
            className="flex items-center gap-1.5 rounded-full border border-ink-900/10 px-3.5 py-2 text-sm font-medium text-ink-900 transition-colors hover:bg-ink-900/5 disabled:opacity-70"
          >
            <svg viewBox="0 0 24 24" className="h-4 w-4" fill={liked ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="1.8">
              <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.6l7 7.2 7-7.2a4.6 4.6 0 000-6.4 4.4 4.4 0 00-6.3 0l-.7.7-.7-.7a4.4 4.4 0 00-6.3 0 4.6 4.6 0 000 6.4z" />
            </svg>
            {likeCount}
          </button>

          <button
            type="button"
            onClick={handleShare}
            className="flex items-center gap-1.5 rounded-full border border-ink-900/10 px-3.5 py-2 text-sm font-medium text-ink-900 transition-colors hover:bg-ink-900/5"
          >
            <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.8">
              <path strokeLinecap="round" strokeLinejoin="round" d="M8.7 10.3l6.6-3.8M8.7 13.7l6.6 3.8M6 12a2.2 2.2 0 100-4.4A2.2 2.2 0 006 12zm0 0a2.2 2.2 0 100 4.4A2.2 2.2 0 006 12zm12-6.6a2.2 2.2 0 100-4.4 2.2 2.2 0 000 4.4zm0 13.2a2.2 2.2 0 100-4.4 2.2 2.2 0 000 4.4z" />
            </svg>
            {copied ? 'Copied!' : 'Share'}
          </button>
        </div>
      </div>

      <div className="flex flex-col gap-2 rounded-xl2 bg-ink-900/[0.03] p-4 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-sm font-medium text-ink-900">Rate this {targetType}</p>
        <div className="flex items-center gap-3">
          <StarPicker value={myRating} onChange={handleRate} size="md" />
          {pending && <span className="text-xs text-ink-900/40">Saving…</span>}
          {feedback && !pending && <span className="text-xs text-ink-900/50">{feedback}</span>}
        </div>
      </div>
    </div>
  );
}
