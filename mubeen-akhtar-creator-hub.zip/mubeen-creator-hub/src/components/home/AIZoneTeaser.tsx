import { ButtonLink } from '@/components/ui/Button';

export function AIZoneTeaser() {
  return (
    <section className="container-page py-14 sm:py-20">
      <div className="overflow-hidden rounded-xl2 border border-ink-900/8 bg-gradient-to-br from-ink-950 to-ink-800 p-8 text-white sm:p-12">
        <p className="text-xs font-semibold uppercase tracking-widest text-brand-400">Coming Soon</p>
        <h2 className="mt-2 max-w-xl font-display text-2xl font-bold sm:text-3xl">
          AI Creator &amp; Student Zone
        </h2>
        <p className="mt-3 max-w-xl text-sm text-white/60 sm:text-base">
          A dedicated space with AI-powered tools for creators and students — caption generators, script
          writers, study assistants and more are on the way.
        </p>
        <ButtonLink href="/ai-zone" variant="secondary" size="md" className="mt-6">
          Preview AI Zone
        </ButtonLink>
      </div>
    </section>
  );
}
