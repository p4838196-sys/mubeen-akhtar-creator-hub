import Image from 'next/image';
import Link from 'next/link';
import { SectionHeading } from '@/components/ui/SectionHeading';
import { EmptyState } from '@/components/ui/EmptyState';
import type { PhotoWithUrl } from '@/lib/data/photos';

export function LatestPhotos({ photos }: { photos: PhotoWithUrl[] }) {
  return (
    <section className="container-page py-14 sm:py-20">
      <SectionHeading eyebrow="Gallery" title="Latest Photos" action={{ label: 'View all photos', href: '/photos' }} />
      <div className="mt-8">
        {photos.length === 0 ? (
          <EmptyState title="No photos yet" description="New photos will appear here once uploaded." />
        ) : (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
            {photos.map((photo) => (
              <Link key={photo.id} href="/photos" className="group relative aspect-square overflow-hidden rounded-xl2 bg-ink-900/5">
                <Image
                  src={photo.url}
                  alt={photo.title}
                  fill
                  loading="lazy"
                  sizes="(max-width: 640px) 50vw, 16vw"
                  className="object-cover transition-transform duration-300 group-hover:scale-105"
                />
              </Link>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
