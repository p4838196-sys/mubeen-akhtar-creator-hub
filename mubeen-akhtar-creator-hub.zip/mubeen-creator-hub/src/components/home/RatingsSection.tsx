import { SectionHeading } from '@/components/ui/SectionHeading';
import { StarDisplay } from '@/components/ui/StarRating';
import type { RatingSummary } from '@/lib/types/database.types';

export function RatingsSection({ summary }: { summary: RatingSummary }) {
  return (
    <section className="bg-ink-900/[0.025] py-14 sm:py-20">
      <div className="container-page">
        <SectionHeading eyebrow="Feedback" title="Audience Ratings" action={{ label: 'Read reviews', href: '/reviews' }} />
        <div className="mt-8 flex flex-col items-start gap-6 rounded-xl2 border border-ink-900/8 bg-white p-6 shadow-card sm:flex-row sm:items-center sm:gap-10 sm:p-8">
          {summary.count > 0 ? (
            <>
              <div className="text-center sm:text-left">
                <p className="font-display text-4xl font-bold text-ink-950">{summary.average?.toFixed(1)}</p>
                <StarDisplay value={summary.average ?? 0} size="md" />
                <p className="mt-1 text-xs text-ink-900/50">{summary.count} review{summary.count !== 1 ? 's' : ''}</p>
              </div>
              <div className="flex w-full flex-1 flex-col gap-1.5">
                {[5, 4, 3, 2, 1].map((star) => {
                  const value = summary.distribution[star as 1 | 2 | 3 | 4 | 5];
                  const pct = summary.count > 0 ? (value / summary.count) * 100 : 0;
                  return (
                    <div key={star} className="flex items-center gap-2 text-xs text-ink-900/50">
                      <span className="w-3">{star}</span>
                      <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-ink-900/8">
                        <div className="h-full rounded-full bg-brand-500" style={{ width: `${pct}%` }} />
                      </div>
                      <span className="w-6 text-right">{value}</span>
                    </div>
                  );
                })}
              </div>
            </>
          ) : (
            <p className="text-sm text-ink-900/50">No ratings yet</p>
          )}
        </div>
      </div>
    </section>
  );
}
