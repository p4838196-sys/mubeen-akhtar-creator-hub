import Image from 'next/image';
import Link from 'next/link';
import { SectionHeading } from '@/components/ui/SectionHeading';
import { EmptyState } from '@/components/ui/EmptyState';
import type { PhotoWithUrl } from '@/lib/data/photos';
import type { VideoWithUrl } from '@/lib/data/videos';

export function FeaturedContent({ photo, video }: { photo: PhotoWithUrl | null; video: VideoWithUrl | null }) {
  if (!photo && !video) {
    return (
      <section className="container-page py-14 sm:py-20">
        <SectionHeading eyebrow="Spotlight" title="Featured Content" />
        <div className="mt-8">
          <EmptyState title="Nothing featured yet" description="Mark a photo or video as featured from the admin dashboard." />
        </div>
      </section>
    );
  }

  return (
    <section className="container-page py-14 sm:py-20">
      <SectionHeading eyebrow="Spotlight" title="Featured Content" />
      <div className="mt-8 grid gap-5 sm:grid-cols-2">
        {photo && (
          <Link href="/photos" className="group relative aspect-[4/3] overflow-hidden rounded-xl2 bg-ink-900/5">
            <Image src={photo.url} alt={photo.title} fill sizes="(max-width: 640px) 100vw, 50vw" className="object-cover transition-transform duration-300 group-hover:scale-105" />
            <div className="absolute inset-0 flex items-end bg-gradient-to-t from-black/60 to-transparent">
              <div className="p-5">
                <p className="text-xs font-semibold uppercase tracking-wide text-brand-300">Featured Photo</p>
                <p className="mt-1 font-display text-lg font-semibold text-white">{photo.title}</p>
              </div>
            </div>
          </Link>
        )}
        {video && (
          <Link href={`/videos/${video.id}`} className="group relative aspect-[4/3] overflow-hidden rounded-xl2 bg-ink-900/5">
            {video.thumbnail_url ? (
              <Image src={video.thumbnail_url} alt={video.title} fill sizes="(max-width: 640px) 100vw, 50vw" className="object-cover transition-transform duration-300 group-hover:scale-105" />
            ) : (
              <div className="h-full w-full bg-ink-900/10" />
            )}
            <div className="absolute inset-0 flex items-end bg-gradient-to-t from-black/60 to-transparent">
              <div className="p-5">
                <p className="text-xs font-semibold uppercase tracking-wide text-brand-300">Featured Video</p>
                <p className="mt-1 font-display text-lg font-semibold text-white">{video.title}</p>
              </div>
            </div>
            <div className="absolute right-4 top-4 flex h-10 w-10 items-center justify-center rounded-full bg-white/90 text-ink-950">
              <svg viewBox="0 0 24 24" className="h-4 w-4 translate-x-0.5" fill="currentColor"><path d="M8 5v14l11-7z" /></svg>
            </div>
          </Link>
        )}
      </div>
    </section>
  );
}
