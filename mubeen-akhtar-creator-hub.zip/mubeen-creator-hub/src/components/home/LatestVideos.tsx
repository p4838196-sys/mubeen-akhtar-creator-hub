import { SectionHeading } from '@/components/ui/SectionHeading';
import { EmptyState } from '@/components/ui/EmptyState';
import { VideoCard } from '@/components/videos/VideoCard';
import type { VideoWithUrl } from '@/lib/data/videos';

export function LatestVideos({ videos }: { videos: VideoWithUrl[] }) {
  return (
    <section className="bg-ink-900/[0.025] py-14 sm:py-20">
      <div className="container-page">
        <SectionHeading eyebrow="Watch" title="Latest Videos" action={{ label: 'View all videos', href: '/videos' }} />
        <div className="mt-8">
          {videos.length === 0 ? (
            <EmptyState title="No videos yet" description="New videos will appear here once uploaded." />
          ) : (
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
              {videos.map((video) => <VideoCard key={video.id} video={video} />)}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
