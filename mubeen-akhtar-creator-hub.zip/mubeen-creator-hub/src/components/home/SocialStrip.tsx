import { SectionHeading } from '@/components/ui/SectionHeading';
import { EmptyState } from '@/components/ui/EmptyState';
import { SocialIcon, platformLabels } from '@/components/social/SocialIcon';
import { formatFollowerCount } from '@/lib/utils/format';
import type { SocialAccount } from '@/lib/types/database.types';

export function SocialStrip({ socials }: { socials: SocialAccount[] }) {
  return (
    <section className="container-page py-14 sm:py-20">
      <SectionHeading eyebrow="Connect" title="Social Media" action={{ label: 'View Social Hub', href: '/social' }} />
      <div className="mt-8">
        {socials.length === 0 ? (
          <EmptyState title="No social accounts added yet" />
        ) : (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {socials.map((s) => (
              <a
                key={s.id}
                href={s.profile_url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 rounded-xl2 border border-ink-900/8 p-4 shadow-card transition-colors hover:border-brand-300"
              >
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-ink-950 text-white">
                  <SocialIcon platform={s.platform} className="h-5 w-5" />
                </div>
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-ink-950">{platformLabels[s.platform]}</p>
                  <p className="truncate text-sm text-ink-900/55">@{s.username}</p>
                </div>
                {s.follower_count !== null && (
                  <span className="ml-auto shrink-0 text-xs font-medium text-ink-900/50">
                    {formatFollowerCount(s.follower_count)} followers
                  </span>
                )}
              </a>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
