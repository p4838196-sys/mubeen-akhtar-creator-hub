import Image from 'next/image';
import { ButtonLink } from '@/components/ui/Button';
import { SocialIcon } from '@/components/social/SocialIcon';
import type { SiteProfile, SocialAccount } from '@/lib/types/database.types';
import type { PhotoWithUrl } from '@/lib/data/photos';
import type { VideoWithUrl } from '@/lib/data/videos';

export function Hero({
  profile,
  socials,
  featured,
}: {
  profile: SiteProfile | null;
  socials: SocialAccount[];
  featured: PhotoWithUrl | VideoWithUrl | null;
}) {
  const name = profile?.display_name || 'Mubeen Akhtar';
  const intro =
    profile?.short_intro ||
    'Creator sharing photography, videos and moments — with a growing hub of social channels and, soon, AI tools.';

  const isPhoto = featured && 'storage_path' in featured && !('source_type' in featured);
  const featuredImageUrl = featured
    ? isPhoto
      ? (featured as PhotoWithUrl).url
      : (featured as VideoWithUrl).thumbnail_url
    : null;

  return (
    <section className="relative overflow-hidden bg-ink-950">
      <div className="container-page grid gap-10 py-14 sm:py-20 lg:grid-cols-2 lg:items-center lg:py-28">
        <div className="animate-fadeUp text-white">
          <div className="mb-6 flex items-center gap-4">
            <div className="relative h-16 w-16 overflow-hidden rounded-full ring-2 ring-white/20 sm:h-20 sm:w-20">
              {profile?.avatar_url ? (
                <Image src={profile.avatar_url} alt={name} fill sizes="80px" className="object-cover" priority />
              ) : (
                <div className="flex h-full w-full items-center justify-center bg-white/10 text-xl font-semibold">
                  {name.charAt(0)}
                </div>
              )}
            </div>
            <div>
              <p className="font-display text-xl font-bold sm:text-2xl">{name}</p>
              {profile?.tagline && <p className="text-sm text-white/60">{profile.tagline}</p>}
            </div>
          </div>

          <h1 className="font-display text-3xl font-bold leading-tight tracking-tight sm:text-4xl lg:text-5xl">
            Photos, videos &amp; moments — all in one creator hub.
          </h1>
          <p className="mt-4 max-w-lg text-base text-white/60 sm:text-lg">{intro}</p>

          <div className="mt-8 flex flex-wrap gap-3">
            <ButtonLink href="/photos" variant="secondary" size="lg">Explore My Content</ButtonLink>
            <ButtonLink href="/social" variant="outline" size="lg" className="border-white/20 text-white hover:bg-white/10">
              Follow Me
            </ButtonLink>
            <ButtonLink href="/ai-zone" variant="ghost" size="lg" className="text-white hover:bg-white/10">
              AI Zone &rarr;
            </ButtonLink>
          </div>

          {socials.length > 0 && (
            <div className="mt-8 flex flex-wrap gap-2.5">
              {socials.slice(0, 6).map((s) => (
                <a
                  key={s.id}
                  href={s.profile_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={s.platform}
                  className="flex h-10 w-10 items-center justify-center rounded-full bg-white/10 text-white transition-colors hover:bg-brand-500"
                >
                  <SocialIcon platform={s.platform} className="h-4.5 w-4.5" />
                </a>
              ))}
            </div>
          )}
        </div>

        <div className="relative mx-auto aspect-[4/5] w-full max-w-md animate-fadeIn overflow-hidden rounded-xl2 bg-white/5 lg:max-w-none">
          {featuredImageUrl ? (
            <Image src={featuredImageUrl} alt="Featured content" fill sizes="(max-width: 1024px) 90vw, 40vw" className="object-cover" priority />
          ) : (
            <div className="flex h-full items-center justify-center text-white/20">
              <svg viewBox="0 0 24 24" className="h-16 w-16" fill="currentColor"><path d="M4 5h16v14H4zM8.5 13l2.5 3 3.5-4.5L19 17H5z" /></svg>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
