import Link from 'next/link';
import type { SocialAccount } from '@/lib/types/database.types';
import { SocialIcon } from '@/components/social/SocialIcon';

export function Footer({ displayName, socials }: { displayName: string; socials: SocialAccount[] }) {
  return (
    <footer className="border-t border-ink-900/8 bg-ink-950 text-white/70">
      <div className="container-page flex flex-col gap-8 py-12 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <p className="font-display text-lg font-semibold text-white">{displayName}</p>
          <p className="mt-2 max-w-sm text-sm text-white/50">
            Creator Hub — photos, videos, socials and (soon) AI tools for creators and students.
          </p>
        </div>

        {socials.length > 0 && (
          <div className="flex flex-wrap gap-3">
            {socials.map((s) => (
              <a
                key={s.id}
                href={s.profile_url}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={s.platform}
                className="flex h-10 w-10 items-center justify-center rounded-full bg-white/10 text-white transition-colors hover:bg-brand-500"
              >
                <SocialIcon platform={s.platform} className="h-4.5 w-4.5" />
              </a>
            ))}
          </div>
        )}
      </div>
      <div className="border-t border-white/10">
        <div className="container-page flex flex-col gap-2 py-5 text-xs text-white/40 sm:flex-row sm:items-center sm:justify-between">
          <p>&copy; {new Date().getFullYear()} {displayName}. All rights reserved.</p>
          <div className="flex gap-4">
            <Link href="/contact" className="hover:text-white/70">Contact</Link>
            <Link href="/admin/login" className="hover:text-white/70">Admin</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
