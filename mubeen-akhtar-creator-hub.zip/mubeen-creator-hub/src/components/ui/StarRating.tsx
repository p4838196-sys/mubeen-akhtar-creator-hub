'use client';

import { useState } from 'react';
import { cn } from '@/lib/utils/cn';

function StarIcon({ filled, half }: { filled: boolean; half?: boolean }) {
  return (
    <svg viewBox="0 0 20 20" className="h-full w-full" aria-hidden="true">
      <defs>
        <linearGradient id="half-star-gradient">
          <stop offset="50%" stopColor="currentColor" />
          <stop offset="50%" stopColor="transparent" stopOpacity="1" />
        </linearGradient>
      </defs>
      <path
        fill={half ? 'url(#half-star-gradient)' : filled ? 'currentColor' : 'none'}
        stroke="currentColor"
        strokeWidth="1.2"
        d="M10 1.5l2.6 5.4 5.9.8-4.3 4.2 1 5.9L10 15l-5.2 2.8 1-5.9-4.3-4.2 5.9-.8L10 1.5z"
      />
    </svg>
  );
}

/** Read-only star display, supports fractional averages (e.g. 3.7). */
export function StarDisplay({ value, size = 'md' }: { value: number; size?: 'sm' | 'md' | 'lg' }) {
  const sizeClass = { sm: 'h-3.5 w-3.5', md: 'h-4.5 w-4.5', lg: 'h-6 w-6' }[size];
  return (
    <div className={cn('flex gap-0.5 text-brand-500', sizeClass === 'h-4.5 w-4.5' ? 'text-brand-500' : '')}>
      {Array.from({ length: 5 }).map((_, i) => {
        const filled = value >= i + 1;
        const half = !filled && value > i && value < i + 1;
        return (
          <span key={i} className={sizeClass}>
            <StarIcon filled={filled} half={half} />
          </span>
        );
      })}
    </div>
  );
}

/** Interactive 1-5 star picker used for submitting a rating or a review. */
export function StarPicker({
  value,
  onChange,
  size = 'lg',
  name,
}: {
  value: number;
  onChange: (v: number) => void;
  size?: 'sm' | 'md' | 'lg';
  name?: string;
}) {
  const [hovered, setHovered] = useState<number | null>(null);
  const sizeClass = { sm: 'h-5 w-5', md: 'h-7 w-7', lg: 'h-9 w-9' }[size];
  const display = hovered ?? value;

  return (
    <div className="flex items-center gap-1" role="radiogroup" aria-label="Star rating">
      {name && <input type="hidden" name={name} value={value} />}
      {Array.from({ length: 5 }).map((_, i) => {
        const starValue = i + 1;
        return (
          <button
            key={i}
            type="button"
            role="radio"
            aria-checked={value === starValue}
            aria-label={`${starValue} star${starValue > 1 ? 's' : ''}`}
            className={cn(sizeClass, 'text-brand-500 transition-transform hover:scale-110')}
            onMouseEnter={() => setHovered(starValue)}
            onMouseLeave={() => setHovered(null)}
            onClick={() => onChange(starValue)}
          >
            <StarIcon filled={display >= starValue} />
          </button>
        );
      })}
    </div>
  );
}
