import { cn } from '@/lib/utils/cn';
import Link from 'next/link';

export function SectionHeading({
  eyebrow,
  title,
  description,
  action,
  className,
}: {
  eyebrow?: string;
  title: string;
  description?: string;
  action?: { label: string; href: string };
  className?: string;
}) {
  return (
    <div className={cn('flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between', className)}>
      <div>
        {eyebrow && (
          <p className="text-xs font-semibold uppercase tracking-widest text-brand-600">{eyebrow}</p>
        )}
        <h2 className="mt-1 font-display text-2xl font-semibold tracking-tight text-ink-950 sm:text-3xl">{title}</h2>
        {description && <p className="mt-2 max-w-2xl text-sm text-ink-900/60 sm:text-base">{description}</p>}
      </div>
      {action && (
        <Link
          href={action.href}
          className="whitespace-nowrap text-sm font-semibold text-brand-600 hover:text-brand-700"
        >
          {action.label} &rarr;
        </Link>
      )}
    </div>
  );
}
