import type { ReactNode } from 'react';

export function EmptyState({
  icon,
  title,
  description,
}: {
  icon?: ReactNode;
  title: string;
  description?: string;
}) {
  return (
    <div className="flex flex-col items-center justify-center rounded-xl2 border border-dashed border-ink-900/15 px-6 py-16 text-center">
      {icon && <div className="mb-4 text-ink-900/30">{icon}</div>}
      <p className="text-base font-medium text-ink-900">{title}</p>
      {description && <p className="mt-1 max-w-sm text-sm text-ink-900/50">{description}</p>}
    </div>
  );
}
