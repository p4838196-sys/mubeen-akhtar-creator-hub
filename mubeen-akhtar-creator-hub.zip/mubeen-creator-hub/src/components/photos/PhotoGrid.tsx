'use client';

import { useState } from 'react';
import Image from 'next/image';
import { PhotoLightbox, type PhotoForLightbox } from './PhotoLightbox';
import { EmptyState } from '@/components/ui/EmptyState';

export function PhotoGrid({ photos }: { photos: PhotoForLightbox[] }) {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  if (photos.length === 0) {
    return (
      <EmptyState
        title="No photos yet"
        description="Photos uploaded from the admin dashboard will show up here."
      />
    );
  }

  return (
    <>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
        {photos.map((photo, i) => (
          <button
            key={photo.id}
            onClick={() => setActiveIndex(i)}
            className="group relative aspect-square overflow-hidden rounded-xl2 bg-ink-900/5"
          >
            <Image
              src={photo.url}
              alt={photo.title}
              fill
              loading="lazy"
              sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
              className="object-cover transition-transform duration-300 group-hover:scale-105"
            />
            {photo.is_featured && (
              <span className="absolute left-2 top-2 rounded-full bg-brand-500 px-2 py-0.5 text-[11px] font-semibold text-white">
                Featured
              </span>
            )}
            <div className="absolute inset-0 flex items-end bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-0 transition-opacity group-hover:opacity-100">
              <p className="line-clamp-1 p-2.5 text-left text-xs font-medium text-white">{photo.title}</p>
            </div>
          </button>
        ))}
      </div>

      {activeIndex !== null && (
        <PhotoLightbox
          photos={photos}
          index={activeIndex}
          onClose={() => setActiveIndex(null)}
          onNavigate={setActiveIndex}
        />
      )}
    </>
  );
}
