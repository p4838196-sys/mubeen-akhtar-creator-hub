'use client';

import { useEffect, useCallback } from 'react';
import Image from 'next/image';
import { formatDate } from '@/lib/utils/format';
import { ContentEngagement } from '@/components/shared/ContentEngagement';
import type { RatingSummary } from '@/lib/types/database.types';
import type { PhotoWithUrl } from '@/lib/data/photos';

export type PhotoForLightbox = PhotoWithUrl & { ratingSummary: RatingSummary; likeCount: number };

export function PhotoLightbox({
  photos,
  index,
  onClose,
  onNavigate,
}: {
  photos: PhotoForLightbox[];
  index: number;
  onClose: () => void;
  onNavigate: (i: number) => void;
}) {
  const photo = photos[index];

  const goPrev = useCallback(() => onNavigate((index - 1 + photos.length) % photos.length), [index, photos.length, onNavigate]);
  const goNext = useCallback(() => onNavigate((index + 1) % photos.length), [index, photos.length, onNavigate]);

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowLeft') goPrev();
      if (e.key === 'ArrowRight') goNext();
    }
    document.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [onClose, goPrev, goNext]);

  if (!photo) return null;
  const shareUrl = typeof window !== 'undefined' ? `${window.location.origin}/photos?photo=${photo.id}` : '';

  return (
    <div className="fixed inset-0 z-[100] flex flex-col bg-black/95 backdrop-blur-sm animate-fadeIn" role="dialog" aria-modal="true">
      <div className="flex items-center justify-between px-4 py-3 text-white sm:px-6">
        <p className="text-sm text-white/60">{index + 1} / {photos.length}</p>
        <button onClick={onClose} aria-label="Close" className="flex h-9 w-9 items-center justify-center rounded-full hover:bg-white/10">
          <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="1.8">
            <path strokeLinecap="round" strokeLinejoin="round" d="M6 6l12 12M18 6L6 18" />
          </svg>
        </button>
      </div>

      <div className="relative flex flex-1 items-center justify-center px-2">
        <button
          onClick={goPrev}
          aria-label="Previous photo"
          className="absolute left-2 z-10 flex h-10 w-10 items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/20 sm:left-6"
        >
          <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2">
            <path strokeLinecap="round" strokeLinejoin="round" d="M15 18l-6-6 6-6" />
          </svg>
        </button>

        <div className="relative h-[45vh] w-full max-w-3xl sm:h-[55vh]">
          <Image src={photo.url} alt={photo.title} fill sizes="90vw" className="object-contain" priority />
        </div>

        <button
          onClick={goNext}
          aria-label="Next photo"
          className="absolute right-2 z-10 flex h-10 w-10 items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/20 sm:right-6"
        >
          <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2">
            <path strokeLinecap="round" strokeLinejoin="round" d="M9 18l6-6-6-6" />
          </svg>
        </button>
      </div>

      <div className="max-h-[40vh] overflow-y-auto rounded-t-2xl bg-white px-4 py-5 sm:px-6">
        <div className="mx-auto max-w-2xl">
          <h2 className="font-display text-lg font-semibold text-ink-950">{photo.title}</h2>
          {photo.description && <p className="mt-1 text-sm text-ink-900/60">{photo.description}</p>}
          <p className="mt-1 text-xs text-ink-900/40">{formatDate(photo.created_at)}</p>

          <div className="mt-4">
            <ContentEngagement
              targetType="photo"
              targetId={photo.id}
              initialSummary={photo.ratingSummary}
              initialLikeCount={photo.likeCount}
              shareUrl={shareUrl}
              shareTitle={photo.title}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
