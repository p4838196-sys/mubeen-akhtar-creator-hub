'use client';

import { useActionState } from 'react';
import { submitContactMessage } from '@/lib/actions/public';

const initialState = { success: false, message: '' };

export function ContactForm() {
  const [state, formAction, pending] = useActionState(submitContactMessage, initialState);

  return (
    <form action={formAction} className="flex flex-col gap-4 rounded-xl2 border border-ink-900/8 bg-white p-6 shadow-card sm:p-8">
      {/* Honeypot field, hidden from real users */}
      <input type="text" name="company" tabIndex={-1} autoComplete="off" className="hidden" aria-hidden="true" />

      <div>
        <label htmlFor="name" className="text-sm font-medium text-ink-900">Name</label>
        <input
          id="name"
          name="name"
          required
          maxLength={100}
          className="mt-1.5 w-full rounded-lg border border-ink-900/15 px-3.5 py-2.5 text-sm outline-none focus:border-brand-500"
          placeholder="Your name"
        />
      </div>

      <div>
        <label htmlFor="email" className="text-sm font-medium text-ink-900">Email</label>
        <input
          id="email"
          name="email"
          type="email"
          required
          maxLength={200}
          className="mt-1.5 w-full rounded-lg border border-ink-900/15 px-3.5 py-2.5 text-sm outline-none focus:border-brand-500"
          placeholder="you@example.com"
        />
      </div>

      <div>
        <label htmlFor="message" className="text-sm font-medium text-ink-900">Message</label>
        <textarea
          id="message"
          name="message"
          required
          minLength={10}
          maxLength={3000}
          rows={6}
          className="mt-1.5 w-full resize-none rounded-lg border border-ink-900/15 px-3.5 py-2.5 text-sm outline-none focus:border-brand-500"
          placeholder="How can I help?"
        />
      </div>

      {state.message && (
        <p className={state.success ? 'text-sm text-green-600' : 'text-sm text-red-600'} role="status">
          {state.message}
        </p>
      )}

      <button
        type="submit"
        disabled={pending}
        className="rounded-full bg-ink-950 px-5 py-3 text-sm font-semibold text-white transition-colors hover:bg-ink-800 disabled:opacity-50"
      >
        {pending ? 'Sending…' : 'Send Message'}
      </button>
    </form>
  );
}
