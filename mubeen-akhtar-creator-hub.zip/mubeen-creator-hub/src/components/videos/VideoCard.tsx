import Link from 'next/link';
import Image from 'next/image';
import type { VideoWithUrl } from '@/lib/data/videos';

export function VideoCard({ video }: { video: VideoWithUrl }) {
  return (
    <Link
      href={`/videos/${video.id}`}
      className="group flex flex-col overflow-hidden rounded-xl2 border border-ink-900/8 bg-white shadow-card transition-shadow hover:shadow-lg"
    >
      <div className="relative aspect-video w-full overflow-hidden bg-ink-900/5">
        {video.thumbnail_url ? (
          <Image
            src={video.thumbnail_url}
            alt={video.title}
            fill
            loading="lazy"
            sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
            className="object-cover transition-transform duration-300 group-hover:scale-105"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center text-ink-900/20">
            <svg viewBox="0 0 24 24" className="h-10 w-10" fill="currentColor"><path d="M8 5v14l11-7z" /></svg>
          </div>
        )}
        <div className="absolute inset-0 flex items-center justify-center bg-black/20 opacity-0 transition-opacity group-hover:opacity-100">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-white/90 text-ink-950">
            <svg viewBox="0 0 24 24" className="h-5 w-5 translate-x-0.5" fill="currentColor"><path d="M8 5v14l11-7z" /></svg>
          </div>
        </div>
        {video.is_featured && (
          <span className="absolute left-2 top-2 rounded-full bg-brand-500 px-2 py-0.5 text-[11px] font-semibold text-white">Featured</span>
        )}
      </div>
      <div className="flex flex-1 flex-col gap-1 p-4">
        {video.category && <p className="text-xs font-semibold uppercase tracking-wide text-brand-600">{video.category}</p>}
        <h3 className="line-clamp-2 font-display text-base font-semibold text-ink-950">{video.title}</h3>
        {video.description && <p className="line-clamp-2 text-sm text-ink-900/55">{video.description}</p>}
      </div>
    </Link>
  );
}
