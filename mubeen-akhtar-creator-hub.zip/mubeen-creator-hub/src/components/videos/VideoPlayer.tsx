import type { VideoWithUrl } from '@/lib/data/videos';

function getYouTubeEmbed(url: string): string | null {
  const match = url.match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/|shorts\/))([\w-]{11})/);
  return match ? `https://www.youtube.com/embed/${match[1]}` : null;
}

export function VideoPlayer({ video }: { video: VideoWithUrl }) {
  if (video.source_type === 'storage') {
    return (
      // eslint-disable-next-line jsx-a11y/media-has-caption
      <video controls preload="metadata" poster={video.thumbnail_url ?? undefined} className="h-full w-full bg-black">
        <source src={video.playback_url} />
      </video>
    );
  }

  const ytEmbed = getYouTubeEmbed(video.playback_url);
  if (ytEmbed) {
    return (
      <iframe
        src={ytEmbed}
        title={video.title}
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
        allowFullScreen
        className="h-full w-full"
      />
    );
  }

  // Generic external link fallback (e.g. TikTok, an unrecognized host)
  return (
    <div className="flex h-full w-full flex-col items-center justify-center gap-3 bg-ink-950 text-white">
      <p className="text-sm text-white/70">This video is hosted externally.</p>
      <a
        href={video.playback_url}
        target="_blank"
        rel="noopener noreferrer"
        className="rounded-full bg-white px-5 py-2.5 text-sm font-semibold text-ink-950"
      >
        Watch on original platform
      </a>
    </div>
  );
}
