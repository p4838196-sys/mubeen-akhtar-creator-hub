'use client';

import { useActionState, useEffect } from 'react';
import { updatePhotoMeta } from '@/lib/actions/admin-photos';
import type { Album, Photo } from '@/lib/types/database.types';

const initialState = { success: false, message: '' };

export function PhotoEditForm({ photo, albums, onSaved }: { photo: Photo; albums: Album[]; onSaved: () => void }) {
  const updateWithId = updatePhotoMeta.bind(null, photo.id);
  const [state, formAction, pending] = useActionState(updateWithId, initialState);

  useEffect(() => {
    if (state.success) onSaved();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.success]);

  return (
    <form action={formAction} className="flex flex-col gap-3">
      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <label className="text-xs font-medium text-ink-900/60">Title</label>
          <input name="title" required defaultValue={photo.title} className="mt-1 w-full rounded-lg border border-ink-900/15 px-3 py-2 text-sm outline-none focus:border-brand-500" />
        </div>
        <div>
          <label className="text-xs font-medium text-ink-900/60">Album</label>
          <select name="album_id" defaultValue={photo.album_id ?? ''} className="mt-1 w-full rounded-lg border border-ink-900/15 px-3 py-2 text-sm outline-none focus:border-brand-500">
            <option value="">No album</option>
            {albums.map((a) => <option key={a.id} value={a.id}>{a.title}</option>)}
          </select>
        </div>
      </div>

      <div>
        <label className="text-xs font-medium text-ink-900/60">Description</label>
        <textarea name="description" rows={2} defaultValue={photo.description ?? ''} className="mt-1 w-full resize-none rounded-lg border border-ink-900/15 px-3 py-2 text-sm outline-none focus:border-brand-500" />
      </div>

      <div className="flex flex-wrap items-center gap-4">
        <label className="flex items-center gap-2 text-sm text-ink-900/70">
          <input type="checkbox" name="is_featured" defaultChecked={photo.is_featured} className="h-4 w-4 rounded border-ink-900/30" /> Featured
        </label>
        <label className="flex items-center gap-2 text-sm text-ink-900/70">
          <input type="checkbox" name="is_published" defaultChecked={photo.is_published} className="h-4 w-4 rounded border-ink-900/30" /> Published
        </label>
        <div>
          <label className="text-xs font-medium text-ink-900/60">Order</label>
          <input type="number" name="display_order" defaultValue={photo.display_order} className="ml-2 w-20 rounded-lg border border-ink-900/15 px-2 py-1.5 text-sm outline-none focus:border-brand-500" />
        </div>
      </div>

      {state.message && <p className={state.success ? 'text-sm text-green-600' : 'text-sm text-red-600'}>{state.message}</p>}

      <button type="submit" disabled={pending} className="self-start rounded-full bg-ink-950 px-4 py-2 text-sm font-semibold text-white hover:bg-ink-800 disabled:opacity-50">
        {pending ? 'Saving…' : 'Save Changes'}
      </button>
    </form>
  );
}
