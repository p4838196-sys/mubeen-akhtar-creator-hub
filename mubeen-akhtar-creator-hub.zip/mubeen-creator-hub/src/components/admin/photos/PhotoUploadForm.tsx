'use client';

import { useActionState, useEffect, useRef } from 'react';
import { createPhoto } from '@/lib/actions/admin-photos';
import type { Album } from '@/lib/types/database.types';

const initialState = { success: false, message: '' };

export function PhotoUploadForm({ albums }: { albums: Album[] }) {
  const [state, formAction, pending] = useActionState(createPhoto, initialState);
  const formRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    if (state.success) formRef.current?.reset();
  }, [state.success]);

  return (
    <form ref={formRef} action={formAction} className="flex flex-col gap-3">
      <div>
        <label className="text-xs font-medium text-ink-900/60">Image file (JPEG/PNG/WebP, max 8MB)</label>
        <input
          type="file"
          name="file"
          accept="image/jpeg,image/png,image/webp"
          required
          className="mt-1 w-full rounded-lg border border-ink-900/15 px-3 py-2 text-sm outline-none file:mr-3 file:rounded-full file:border-0 file:bg-ink-950 file:px-3.5 file:py-1.5 file:text-xs file:font-semibold file:text-white"
        />
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <label className="text-xs font-medium text-ink-900/60">Title</label>
          <input name="title" required className="mt-1 w-full rounded-lg border border-ink-900/15 px-3 py-2 text-sm outline-none focus:border-brand-500" />
        </div>
        <div>
          <label className="text-xs font-medium text-ink-900/60">Album</label>
          <select name="album_id" className="mt-1 w-full rounded-lg border border-ink-900/15 px-3 py-2 text-sm outline-none focus:border-brand-500">
            <option value="">No album</option>
            {albums.map((a) => <option key={a.id} value={a.id}>{a.title}</option>)}
          </select>
        </div>
      </div>

      <div>
        <label className="text-xs font-medium text-ink-900/60">Description</label>
        <textarea name="description" rows={2} className="mt-1 w-full resize-none rounded-lg border border-ink-900/15 px-3 py-2 text-sm outline-none focus:border-brand-500" />
      </div>

      <div className="flex flex-wrap items-center gap-4">
        <label className="flex items-center gap-2 text-sm text-ink-900/70">
          <input type="checkbox" name="is_featured" className="h-4 w-4 rounded border-ink-900/30" /> Featured
        </label>
        <label className="flex items-center gap-2 text-sm text-ink-900/70">
          <input type="checkbox" name="is_published" defaultChecked className="h-4 w-4 rounded border-ink-900/30" /> Published
        </label>
        <div>
          <label className="text-xs font-medium text-ink-900/60">Order</label>
          <input type="number" name="display_order" defaultValue={0} className="ml-2 w-20 rounded-lg border border-ink-900/15 px-2 py-1.5 text-sm outline-none focus:border-brand-500" />
        </div>
      </div>

      {state.message && <p className={state.success ? 'text-sm text-green-600' : 'text-sm text-red-600'}>{state.message}</p>}

      <button
        type="submit"
        disabled={pending}
        className="self-start rounded-full bg-ink-950 px-4 py-2 text-sm font-semibold text-white hover:bg-ink-800 disabled:opacity-50"
      >
        {pending ? 'Uploading…' : 'Upload Photo'}
      </button>
    </form>
  );
}
