'use client';

import { useState } from 'react';
import Image from 'next/image';
import { PhotoUploadForm } from './PhotoUploadForm';
import { PhotoEditForm } from './PhotoEditForm';
import { ConfirmDeleteButton } from '@/components/admin/ConfirmDeleteButton';
import { deletePhoto } from '@/lib/actions/admin-photos';
import type { Album, Photo } from '@/lib/types/database.types';

export function PhotosManager({ photos, albums }: { photos: (Photo & { url: string })[]; albums: Album[] }) {
  const [editingId, setEditingId] = useState<string | null>(null);

  return (
    <div className="flex flex-col gap-6">
      <div className="rounded-xl2 border border-ink-900/8 bg-white p-5 shadow-card">
        <h2 className="font-display text-base font-semibold text-ink-950">Upload Photo</h2>
        <div className="mt-4"><PhotoUploadForm albums={albums} /></div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        {photos.length === 0 && <p className="text-sm text-ink-900/40">No photos yet.</p>}
        {photos.map((photo) => (
          <div key={photo.id} className="flex flex-col gap-3 rounded-xl2 border border-ink-900/8 bg-white p-4 shadow-card">
            <div className="flex gap-3">
              <div className="relative h-20 w-20 shrink-0 overflow-hidden rounded-lg bg-ink-900/5">
                <Image src={photo.url} alt={photo.title} fill sizes="80px" className="object-cover" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate font-medium text-ink-950">{photo.title}</p>
                <p className="text-xs text-ink-900/40">
                  {photo.is_published ? 'Published' : 'Draft'} {photo.is_featured && '· Featured'}
                </p>
                <div className="mt-2 flex gap-3">
                  <button onClick={() => setEditingId(editingId === photo.id ? null : photo.id)} className="text-xs font-semibold text-brand-600 hover:text-brand-700">
                    {editingId === photo.id ? 'Close' : 'Edit'}
                  </button>
                  <ConfirmDeleteButton onDelete={() => deletePhoto(photo.id, photo.storage_path)} />
                </div>
              </div>
            </div>
            {editingId === photo.id && (
              <div className="border-t border-ink-900/8 pt-3">
                <PhotoEditForm photo={photo} albums={albums} onSaved={() => setEditingId(null)} />
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
