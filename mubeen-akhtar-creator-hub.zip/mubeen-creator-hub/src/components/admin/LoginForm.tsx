'use client';

import { useActionState } from 'react';
import { useSearchParams } from 'next/navigation';
import { loginAction } from '@/lib/actions/auth';

const initialState = { error: null as string | null };

export function LoginForm() {
  const [state, formAction, pending] = useActionState(loginAction, initialState);
  const searchParams = useSearchParams();
  const redirectedFrom = searchParams.get('redirectedFrom');

  return (
    <form action={formAction} className="flex flex-col gap-4">
      {redirectedFrom && (
        <p className="rounded-lg bg-brand-50 px-3.5 py-2.5 text-xs text-brand-700">
          Please log in to access {redirectedFrom}.
        </p>
      )}

      <div>
        <label htmlFor="email" className="text-sm font-medium text-ink-900">Email</label>
        <input
          id="email"
          name="email"
          type="email"
          required
          autoComplete="email"
          className="mt-1.5 w-full rounded-lg border border-ink-900/15 px-3.5 py-2.5 text-sm outline-none focus:border-brand-500"
          placeholder="you@example.com"
        />
      </div>

      <div>
        <label htmlFor="password" className="text-sm font-medium text-ink-900">Password</label>
        <input
          id="password"
          name="password"
          type="password"
          required
          autoComplete="current-password"
          className="mt-1.5 w-full rounded-lg border border-ink-900/15 px-3.5 py-2.5 text-sm outline-none focus:border-brand-500"
          placeholder="••••••••"
        />
      </div>

      {state.error && (
        <p className="rounded-lg bg-red-50 px-3.5 py-2.5 text-sm text-red-600" role="alert">
          {state.error}
        </p>
      )}

      <button
        type="submit"
        disabled={pending}
        className="mt-1 rounded-full bg-ink-950 px-5 py-3 text-sm font-semibold text-white transition-colors hover:bg-ink-800 disabled:opacity-50"
      >
        {pending ? 'Signing in…' : 'Sign In'}
      </button>
    </form>
  );
}
