'use client';

import { useActionState } from 'react';
import Image from 'next/image';
import { uploadProfileImage } from '@/lib/actions/admin-settings';

const initialState = { success: false, message: '' };

export function ProfileImageForm({
  profileId,
  field,
  label,
  currentUrl,
}: {
  profileId: string;
  field: 'avatar_url' | 'hero_image_url';
  label: string;
  currentUrl: string | null;
}) {
  const action = uploadProfileImage.bind(null, profileId, field);
  const [state, formAction, pending] = useActionState(action, initialState);

  return (
    <div className="rounded-xl2 border border-ink-900/8 bg-white p-5 shadow-card">
      <p className="text-sm font-semibold text-ink-950">{label}</p>
      <div className="mt-3 flex items-center gap-4">
        <div className="relative h-16 w-16 shrink-0 overflow-hidden rounded-full bg-ink-900/5">
          {currentUrl && <Image src={currentUrl} alt={label} fill sizes="64px" className="object-cover" />}
        </div>
        <form action={formAction} className="flex flex-1 flex-col gap-2">
          <input
            type="file"
            name="file"
            accept="image/jpeg,image/png,image/webp"
            required
            className="w-full text-xs file:mr-3 file:rounded-full file:border-0 file:bg-ink-950 file:px-3 file:py-1.5 file:text-xs file:font-semibold file:text-white"
          />
          <button type="submit" disabled={pending} className="self-start rounded-full bg-ink-900/5 px-3.5 py-1.5 text-xs font-semibold text-ink-900 hover:bg-ink-900/10 disabled:opacity-50">
            {pending ? 'Uploading…' : 'Upload'}
          </button>
          {state.message && <p className={state.success ? 'text-xs text-green-600' : 'text-xs text-red-600'}>{state.message}</p>}
        </form>
      </div>
    </div>
  );
}
