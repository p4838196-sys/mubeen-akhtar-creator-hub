'use client';

import { useActionState } from 'react';
import { updateSiteSettings } from '@/lib/actions/admin-settings';
import type { SiteSettings } from '@/lib/types/database.types';

const initialState = { success: false, message: '' };

export function SiteSettingsForm({ settings }: { settings: SiteSettings }) {
  const action = updateSiteSettings.bind(null, settings.id);
  const [state, formAction, pending] = useActionState(action, initialState);

  return (
    <form action={formAction} className="flex flex-col gap-4">
      <div>
        <label className="text-xs font-medium text-ink-900/60">Site title</label>
        <input name="site_title" required defaultValue={settings.site_title} className="mt-1 w-full rounded-lg border border-ink-900/15 px-3 py-2 text-sm outline-none focus:border-brand-500" />
      </div>
      <div>
        <label className="text-xs font-medium text-ink-900/60">Site description (SEO)</label>
        <textarea name="site_description" rows={2} defaultValue={settings.site_description} className="mt-1 w-full resize-none rounded-lg border border-ink-900/15 px-3 py-2 text-sm outline-none focus:border-brand-500" />
      </div>
      <div>
        <label className="text-xs font-medium text-ink-900/60">Public contact email (optional)</label>
        <input name="contact_email" type="email" defaultValue={settings.contact_email ?? ''} className="mt-1 w-full rounded-lg border border-ink-900/15 px-3 py-2 text-sm outline-none focus:border-brand-500" />
      </div>

      <div className="flex flex-col gap-2">
        <label className="flex items-center gap-2 text-sm text-ink-900/70">
          <input type="checkbox" name="reviews_require_review" defaultChecked={settings.reviews_require_review} className="h-4 w-4 rounded border-ink-900/30" />
          Require moderation before reviews appear publicly
        </label>
        <label className="flex items-center gap-2 text-sm text-ink-900/70">
          <input type="checkbox" name="ai_zone_enabled" defaultChecked={settings.ai_zone_enabled} className="h-4 w-4 rounded border-ink-900/30" />
          AI Zone tools enabled (Phase 3 — leave off for now)
        </label>
        <label className="flex items-center gap-2 text-sm text-ink-900/70">
          <input type="checkbox" name="maintenance_mode" defaultChecked={settings.maintenance_mode} className="h-4 w-4 rounded border-ink-900/30" />
          Maintenance mode
        </label>
      </div>

      {state.message && <p className={state.success ? 'text-sm text-green-600' : 'text-sm text-red-600'}>{state.message}</p>}

      <button type="submit" disabled={pending} className="self-start rounded-full bg-ink-950 px-5 py-2.5 text-sm font-semibold text-white hover:bg-ink-800 disabled:opacity-50">
        {pending ? 'Saving…' : 'Save Settings'}
      </button>
    </form>
  );
}
