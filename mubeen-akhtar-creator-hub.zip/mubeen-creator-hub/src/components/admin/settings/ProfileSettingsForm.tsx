'use client';

import { useActionState, useEffect } from 'react';
import { updateSiteProfile } from '@/lib/actions/admin-settings';
import type { SiteProfile } from '@/lib/types/database.types';

const initialState = { success: false, message: '' };

export function ProfileSettingsForm({ profile }: { profile: SiteProfile }) {
  const action = updateSiteProfile.bind(null, profile.id);
  const [state, formAction, pending] = useActionState(action, initialState);

  useEffect(() => {}, [state.success]);

  return (
    <form action={formAction} className="flex flex-col gap-4">
      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label className="text-xs font-medium text-ink-900/60">Display name</label>
          <input name="display_name" required defaultValue={profile.display_name} className="mt-1 w-full rounded-lg border border-ink-900/15 px-3 py-2 text-sm outline-none focus:border-brand-500" />
        </div>
        <div>
          <label className="text-xs font-medium text-ink-900/60">Tagline</label>
          <input name="tagline" defaultValue={profile.tagline} className="mt-1 w-full rounded-lg border border-ink-900/15 px-3 py-2 text-sm outline-none focus:border-brand-500" />
        </div>
      </div>

      <div>
        <label className="text-xs font-medium text-ink-900/60">Short intro (shown on Home hero)</label>
        <textarea name="short_intro" rows={2} defaultValue={profile.short_intro} className="mt-1 w-full resize-none rounded-lg border border-ink-900/15 px-3 py-2 text-sm outline-none focus:border-brand-500" />
      </div>

      <div>
        <label className="text-xs font-medium text-ink-900/60">Biography</label>
        <textarea name="bio" rows={4} defaultValue={profile.bio} className="mt-1 w-full resize-none rounded-lg border border-ink-900/15 px-3 py-2 text-sm outline-none focus:border-brand-500" />
      </div>

      <div>
        <label className="text-xs font-medium text-ink-900/60">Creator journey</label>
        <textarea name="journey" rows={4} defaultValue={profile.journey} className="mt-1 w-full resize-none rounded-lg border border-ink-900/15 px-3 py-2 text-sm outline-none focus:border-brand-500" />
      </div>

      <div>
        <label className="text-xs font-medium text-ink-900/60">Future vision</label>
        <textarea name="future_vision" rows={3} defaultValue={profile.future_vision} className="mt-1 w-full resize-none rounded-lg border border-ink-900/15 px-3 py-2 text-sm outline-none focus:border-brand-500" />
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label className="text-xs font-medium text-ink-900/60">Interests (comma-separated)</label>
          <input name="interests" defaultValue={profile.interests.join(', ')} className="mt-1 w-full rounded-lg border border-ink-900/15 px-3 py-2 text-sm outline-none focus:border-brand-500" />
        </div>
        <div>
          <label className="text-xs font-medium text-ink-900/60">Skills (comma-separated)</label>
          <input name="skills" defaultValue={profile.skills.join(', ')} className="mt-1 w-full rounded-lg border border-ink-900/15 px-3 py-2 text-sm outline-none focus:border-brand-500" />
        </div>
      </div>

      {state.message && <p className={state.success ? 'text-sm text-green-600' : 'text-sm text-red-600'}>{state.message}</p>}

      <button type="submit" disabled={pending} className="self-start rounded-full bg-ink-950 px-5 py-2.5 text-sm font-semibold text-white hover:bg-ink-800 disabled:opacity-50">
        {pending ? 'Saving…' : 'Save Profile'}
      </button>
    </form>
  );
}
