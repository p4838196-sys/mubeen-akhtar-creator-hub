'use client';

import { useActionState, useEffect, useRef } from 'react';
import { upsertAlbum } from '@/lib/actions/admin-albums';
import type { Album } from '@/lib/types/database.types';

const initialState = { success: false, message: '' };

export function AlbumForm({ album, onSaved }: { album?: Album; onSaved?: () => void }) {
  const [state, formAction, pending] = useActionState(upsertAlbum, initialState);
  const formRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    if (state.success) {
      if (!album) formRef.current?.reset();
      onSaved?.();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.success]);

  return (
    <form ref={formRef} action={formAction} className="flex flex-col gap-3">
      {album && <input type="hidden" name="id" value={album.id} />}

      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <label className="text-xs font-medium text-ink-900/60">Title</label>
          <input
            name="title"
            required
            defaultValue={album?.title}
            className="mt-1 w-full rounded-lg border border-ink-900/15 px-3 py-2 text-sm outline-none focus:border-brand-500"
          />
        </div>
        <div>
          <label className="text-xs font-medium text-ink-900/60">Slug</label>
          <input
            name="slug"
            required
            defaultValue={album?.slug}
            placeholder="e.g. travel-2026"
            className="mt-1 w-full rounded-lg border border-ink-900/15 px-3 py-2 text-sm outline-none focus:border-brand-500"
          />
        </div>
      </div>

      <div>
        <label className="text-xs font-medium text-ink-900/60">Description</label>
        <textarea
          name="description"
          rows={2}
          defaultValue={album?.description ?? ''}
          className="mt-1 w-full resize-none rounded-lg border border-ink-900/15 px-3 py-2 text-sm outline-none focus:border-brand-500"
        />
      </div>

      <div className="flex flex-wrap items-center gap-4">
        <div>
          <label className="text-xs font-medium text-ink-900/60">Display order</label>
          <input
            type="number"
            name="display_order"
            defaultValue={album?.display_order ?? 0}
            className="mt-1 w-24 rounded-lg border border-ink-900/15 px-3 py-2 text-sm outline-none focus:border-brand-500"
          />
        </div>
        <label className="flex items-center gap-2 text-sm text-ink-900/70">
          <input type="checkbox" name="is_active" defaultChecked={album?.is_active ?? true} className="h-4 w-4 rounded border-ink-900/30" />
          Active (visible publicly)
        </label>
      </div>

      {state.message && <p className={state.success ? 'text-sm text-green-600' : 'text-sm text-red-600'}>{state.message}</p>}

      <button
        type="submit"
        disabled={pending}
        className="self-start rounded-full bg-ink-950 px-4 py-2 text-sm font-semibold text-white hover:bg-ink-800 disabled:opacity-50"
      >
        {pending ? 'Saving…' : album ? 'Save Changes' : 'Create Album'}
      </button>
    </form>
  );
}
