'use client';

import { useState } from 'react';
import { AlbumForm } from './AlbumForm';
import { ConfirmDeleteButton } from '@/components/admin/ConfirmDeleteButton';
import { deleteAlbum } from '@/lib/actions/admin-albums';
import type { Album } from '@/lib/types/database.types';

export function AlbumsManager({ albums }: { albums: Album[] }) {
  const [editingId, setEditingId] = useState<string | null>(null);

  return (
    <div className="flex flex-col gap-6">
      <div className="rounded-xl2 border border-ink-900/8 bg-white p-5 shadow-card">
        <h2 className="font-display text-base font-semibold text-ink-950">New Album</h2>
        <div className="mt-4"><AlbumForm /></div>
      </div>

      <div className="flex flex-col gap-3">
        {albums.length === 0 && <p className="text-sm text-ink-900/40">No albums yet.</p>}
        {albums.map((album) => (
          <div key={album.id} className="rounded-xl2 border border-ink-900/8 bg-white p-5 shadow-card">
            {editingId === album.id ? (
              <AlbumForm album={album} onSaved={() => setEditingId(null)} />
            ) : (
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="font-medium text-ink-950">{album.title} <span className="text-ink-900/40">/{album.slug}</span></p>
                  {album.description && <p className="mt-1 text-sm text-ink-900/50">{album.description}</p>}
                  <p className="mt-1 text-xs text-ink-900/40">{album.is_active ? 'Active' : 'Hidden'} · order {album.display_order}</p>
                </div>
                <div className="flex shrink-0 flex-col items-end gap-2">
                  <button onClick={() => setEditingId(album.id)} className="text-xs font-semibold text-brand-600 hover:text-brand-700">Edit</button>
                  <ConfirmDeleteButton onDelete={() => deleteAlbum(album.id)} />
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
