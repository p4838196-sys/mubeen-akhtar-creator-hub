'use client';

import { useActionState, useEffect, useRef } from 'react';
import { upsertSocialAccount } from '@/lib/actions/admin-social';
import type { Platform, SocialAccount } from '@/lib/types/database.types';
import { platformLabels } from '@/components/social/SocialIcon';

const initialState = { success: false, message: '' };
const PLATFORMS = Object.keys(platformLabels) as Platform[];

export function SocialAccountForm({ account, onSaved }: { account?: SocialAccount; onSaved?: () => void }) {
  const [state, formAction, pending] = useActionState(upsertSocialAccount, initialState);
  const formRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    if (state.success) {
      if (!account) formRef.current?.reset();
      onSaved?.();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.success]);

  return (
    <form ref={formRef} action={formAction} className="flex flex-col gap-3">
      {account && <input type="hidden" name="id" value={account.id} />}

      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <label className="text-xs font-medium text-ink-900/60">Platform</label>
          <select name="platform" required defaultValue={account?.platform ?? 'instagram'} className="mt-1 w-full rounded-lg border border-ink-900/15 px-3 py-2 text-sm outline-none focus:border-brand-500">
            {PLATFORMS.map((p) => <option key={p} value={p}>{platformLabels[p]}</option>)}
          </select>
        </div>
        <div>
          <label className="text-xs font-medium text-ink-900/60">Username</label>
          <input name="username" required defaultValue={account?.username} className="mt-1 w-full rounded-lg border border-ink-900/15 px-3 py-2 text-sm outline-none focus:border-brand-500" />
        </div>
      </div>

      <div>
        <label className="text-xs font-medium text-ink-900/60">Profile URL</label>
        <input name="profile_url" type="url" required defaultValue={account?.profile_url} className="mt-1 w-full rounded-lg border border-ink-900/15 px-3 py-2 text-sm outline-none focus:border-brand-500" />
      </div>

      <div className="flex flex-wrap items-center gap-4">
        <div>
          <label className="text-xs font-medium text-ink-900/60">Follower count (optional)</label>
          <input type="number" name="follower_count" min={0} defaultValue={account?.follower_count ?? ''} className="mt-1 w-32 rounded-lg border border-ink-900/15 px-3 py-2 text-sm outline-none focus:border-brand-500" />
        </div>
        <div>
          <label className="text-xs font-medium text-ink-900/60">Display order</label>
          <input type="number" name="display_order" defaultValue={account?.display_order ?? 0} className="mt-1 w-24 rounded-lg border border-ink-900/15 px-3 py-2 text-sm outline-none focus:border-brand-500" />
        </div>
        <label className="flex items-center gap-2 text-sm text-ink-900/70">
          <input type="checkbox" name="is_active" defaultChecked={account?.is_active ?? true} className="h-4 w-4 rounded border-ink-900/30" /> Active
        </label>
      </div>

      {state.message && <p className={state.success ? 'text-sm text-green-600' : 'text-sm text-red-600'}>{state.message}</p>}

      <button type="submit" disabled={pending} className="self-start rounded-full bg-ink-950 px-4 py-2 text-sm font-semibold text-white hover:bg-ink-800 disabled:opacity-50">
        {pending ? 'Saving…' : account ? 'Save Changes' : 'Add Account'}
      </button>
    </form>
  );
}
