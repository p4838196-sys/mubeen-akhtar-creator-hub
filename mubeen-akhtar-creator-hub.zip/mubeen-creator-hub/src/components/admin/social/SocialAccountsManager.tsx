'use client';

import { useState } from 'react';
import { SocialAccountForm } from './SocialAccountForm';
import { ConfirmDeleteButton } from '@/components/admin/ConfirmDeleteButton';
import { deleteSocialAccount } from '@/lib/actions/admin-social';
import { SocialIcon, platformLabels } from '@/components/social/SocialIcon';
import type { SocialAccount } from '@/lib/types/database.types';

export function SocialAccountsManager({ accounts }: { accounts: SocialAccount[] }) {
  const [editingId, setEditingId] = useState<string | null>(null);

  return (
    <div className="flex flex-col gap-6">
      <div className="rounded-xl2 border border-ink-900/8 bg-white p-5 shadow-card">
        <h2 className="font-display text-base font-semibold text-ink-950">Add Social Account</h2>
        <div className="mt-4"><SocialAccountForm /></div>
      </div>

      <div className="flex flex-col gap-3">
        {accounts.length === 0 && <p className="text-sm text-ink-900/40">No social accounts yet.</p>}
        {accounts.map((account) => (
          <div key={account.id} className="rounded-xl2 border border-ink-900/8 bg-white p-5 shadow-card">
            {editingId === account.id ? (
              <SocialAccountForm account={account} onSaved={() => setEditingId(null)} />
            ) : (
              <div className="flex items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-ink-950 text-white">
                    <SocialIcon platform={account.platform} className="h-4.5 w-4.5" />
                  </div>
                  <div>
                    <p className="font-medium text-ink-950">{platformLabels[account.platform]} · @{account.username}</p>
                    <p className="text-xs text-ink-900/40">{account.is_active ? 'Active' : 'Hidden'} · order {account.display_order}</p>
                  </div>
                </div>
                <div className="flex shrink-0 flex-col items-end gap-2">
                  <button onClick={() => setEditingId(account.id)} className="text-xs font-semibold text-brand-600 hover:text-brand-700">Edit</button>
                  <ConfirmDeleteButton onDelete={() => deleteSocialAccount(account.id)} />
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
