'use client';

import { useState, useTransition } from 'react';

export function ConfirmDeleteButton({
  onDelete,
  label = 'Delete',
  confirmText = 'Are you sure? This cannot be undone.',
}: {
  onDelete: () => Promise<{ success: boolean; message: string }>;
  label?: string;
  confirmText?: string;
}) {
  const [confirming, setConfirming] = useState(false);
  const [pending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);

  if (confirming) {
    return (
      <div className="flex items-center gap-2">
        <span className="text-xs text-ink-900/50">{confirmText}</span>
        <button
          type="button"
          disabled={pending}
          onClick={() =>
            startTransition(async () => {
              const result = await onDelete();
              if (!result.success) setError(result.message);
              else setConfirming(false);
            })
          }
          className="rounded-full bg-red-600 px-3 py-1 text-xs font-semibold text-white hover:bg-red-700 disabled:opacity-50"
        >
          {pending ? 'Deleting…' : 'Confirm'}
        </button>
        <button type="button" onClick={() => setConfirming(false)} className="text-xs text-ink-900/50 hover:text-ink-900">
          Cancel
        </button>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-end gap-1">
      <button type="button" onClick={() => setConfirming(true)} className="text-xs font-semibold text-red-600 hover:text-red-700">
        {label}
      </button>
      {error && <span className="text-xs text-red-500">{error}</span>}
    </div>
  );
}
