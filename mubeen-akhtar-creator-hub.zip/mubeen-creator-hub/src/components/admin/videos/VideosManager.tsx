'use client';

import { useState } from 'react';
import { VideoForm } from './VideoForm';
import { ConfirmDeleteButton } from '@/components/admin/ConfirmDeleteButton';
import { deleteVideo } from '@/lib/actions/admin-videos';
import type { Video } from '@/lib/types/database.types';

export function VideosManager({ videos }: { videos: Video[] }) {
  const [editingId, setEditingId] = useState<string | null>(null);

  return (
    <div className="flex flex-col gap-6">
      <div className="rounded-xl2 border border-ink-900/8 bg-white p-5 shadow-card">
        <h2 className="font-display text-base font-semibold text-ink-950">Add Video</h2>
        <div className="mt-4"><VideoForm /></div>
      </div>

      <div className="flex flex-col gap-3">
        {videos.length === 0 && <p className="text-sm text-ink-900/40">No videos yet.</p>}
        {videos.map((video) => (
          <div key={video.id} className="rounded-xl2 border border-ink-900/8 bg-white p-5 shadow-card">
            {editingId === video.id ? (
              <VideoForm video={video} onSaved={() => setEditingId(null)} />
            ) : (
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="font-medium text-ink-950">{video.title}</p>
                  <p className="mt-1 text-xs text-ink-900/40">
                    {video.source_type === 'storage' ? 'Hosted' : 'External'} · {video.is_published ? 'Published' : 'Draft'}
                    {video.is_featured && ' · Featured'}
                  </p>
                </div>
                <div className="flex shrink-0 flex-col items-end gap-2">
                  <button onClick={() => setEditingId(video.id)} className="text-xs font-semibold text-brand-600 hover:text-brand-700">Edit</button>
                  <ConfirmDeleteButton onDelete={() => deleteVideo(video.id, video.storage_path)} />
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
