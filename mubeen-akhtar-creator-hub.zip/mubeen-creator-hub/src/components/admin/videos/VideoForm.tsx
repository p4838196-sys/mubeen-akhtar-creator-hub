'use client';

import { useActionState, useEffect, useRef, useState } from 'react';
import { createVideo, updateVideoMeta } from '@/lib/actions/admin-videos';
import type { Video } from '@/lib/types/database.types';

const initialState = { success: false, message: '' };

export function VideoForm({ video, onSaved }: { video?: Video; onSaved?: () => void }) {
  const action = video ? updateVideoMeta.bind(null, video.id) : createVideo;
  const [state, formAction, pending] = useActionState(action, initialState);
  const [sourceType, setSourceType] = useState<'storage' | 'external'>(video?.source_type ?? 'external');
  const formRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    if (state.success) {
      if (!video) formRef.current?.reset();
      onSaved?.();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.success]);

  return (
    <form ref={formRef} action={formAction} className="flex flex-col gap-3">
      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <label className="text-xs font-medium text-ink-900/60">Title</label>
          <input name="title" required defaultValue={video?.title} className="mt-1 w-full rounded-lg border border-ink-900/15 px-3 py-2 text-sm outline-none focus:border-brand-500" />
        </div>
        <div>
          <label className="text-xs font-medium text-ink-900/60">Category</label>
          <input name="category" defaultValue={video?.category ?? ''} className="mt-1 w-full rounded-lg border border-ink-900/15 px-3 py-2 text-sm outline-none focus:border-brand-500" />
        </div>
      </div>

      <div>
        <label className="text-xs font-medium text-ink-900/60">Description</label>
        <textarea name="description" rows={2} defaultValue={video?.description ?? ''} className="mt-1 w-full resize-none rounded-lg border border-ink-900/15 px-3 py-2 text-sm outline-none focus:border-brand-500" />
      </div>

      <div>
        <label className="text-xs font-medium text-ink-900/60">Source</label>
        <div className="mt-1 flex gap-2">
          <button type="button" onClick={() => setSourceType('external')} disabled={!!video} className={`rounded-full px-3.5 py-1.5 text-xs font-semibold disabled:opacity-40 ${sourceType === 'external' ? 'bg-ink-950 text-white' : 'bg-ink-900/5 text-ink-900/60'}`}>
            External Link
          </button>
          <button type="button" onClick={() => setSourceType('storage')} disabled={!!video} className={`rounded-full px-3.5 py-1.5 text-xs font-semibold disabled:opacity-40 ${sourceType === 'storage' ? 'bg-ink-950 text-white' : 'bg-ink-900/5 text-ink-900/60'}`}>
            Upload File
          </button>
        </div>
        {video && <p className="mt-1 text-xs text-ink-900/40">Source type can&apos;t be changed after creation — delete and re-add if needed.</p>}
        <input type="hidden" name="source_type" value={sourceType} />
      </div>

      {sourceType === 'external' ? (
        <div>
          <label className="text-xs font-medium text-ink-900/60">External video URL (YouTube, TikTok, etc.)</label>
          <input name="external_url" type="url" defaultValue={video?.external_url ?? ''} required={sourceType === 'external'} className="mt-1 w-full rounded-lg border border-ink-900/15 px-3 py-2 text-sm outline-none focus:border-brand-500" />
        </div>
      ) : (
        !video && (
          <div>
            <label className="text-xs font-medium text-ink-900/60">Video file (MP4/WebM/MOV, max 200MB)</label>
            <input type="file" name="file" accept="video/mp4,video/webm,video/quicktime" required className="mt-1 w-full rounded-lg border border-ink-900/15 px-3 py-2 text-sm outline-none file:mr-3 file:rounded-full file:border-0 file:bg-ink-950 file:px-3.5 file:py-1.5 file:text-xs file:font-semibold file:text-white" />
            <p className="mt-1 text-xs text-ink-900/40">For large files, prefer an external link (e.g. unlisted YouTube) to keep storage costs low.</p>
          </div>
        )
      )}

      <div>
        <label className="text-xs font-medium text-ink-900/60">Thumbnail URL (optional)</label>
        <input name="thumbnail_url" type="url" defaultValue={video?.thumbnail_url ?? ''} className="mt-1 w-full rounded-lg border border-ink-900/15 px-3 py-2 text-sm outline-none focus:border-brand-500" />
      </div>

      <div className="flex flex-wrap items-center gap-4">
        <label className="flex items-center gap-2 text-sm text-ink-900/70">
          <input type="checkbox" name="is_featured" defaultChecked={video?.is_featured} className="h-4 w-4 rounded border-ink-900/30" /> Featured
        </label>
        <label className="flex items-center gap-2 text-sm text-ink-900/70">
          <input type="checkbox" name="is_published" defaultChecked={video?.is_published ?? true} className="h-4 w-4 rounded border-ink-900/30" /> Published
        </label>
        <div>
          <label className="text-xs font-medium text-ink-900/60">Order</label>
          <input type="number" name="display_order" defaultValue={video?.display_order ?? 0} className="ml-2 w-20 rounded-lg border border-ink-900/15 px-2 py-1.5 text-sm outline-none focus:border-brand-500" />
        </div>
      </div>

      {state.message && <p className={state.success ? 'text-sm text-green-600' : 'text-sm text-red-600'}>{state.message}</p>}

      <button type="submit" disabled={pending} className="self-start rounded-full bg-ink-950 px-4 py-2 text-sm font-semibold text-white hover:bg-ink-800 disabled:opacity-50">
        {pending ? 'Saving…' : video ? 'Save Changes' : 'Add Video'}
      </button>
    </form>
  );
}
