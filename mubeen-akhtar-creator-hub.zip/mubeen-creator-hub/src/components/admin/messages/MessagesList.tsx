'use client';

import { useState, useTransition } from 'react';
import { setMessageStatus, deleteMessage } from '@/lib/actions/admin-messages';
import { ConfirmDeleteButton } from '@/components/admin/ConfirmDeleteButton';
import { formatDate } from '@/lib/utils/format';
import type { ContactMessage } from '@/lib/types/database.types';
import { cn } from '@/lib/utils/cn';

export function MessagesList({ messages }: { messages: ContactMessage[] }) {
  const [filter, setFilter] = useState<'all' | 'new'>('all');
  const [pending, startTransition] = useTransition();

  const filtered = filter === 'new' ? messages.filter((m) => m.status === 'new') : messages;

  return (
    <div>
      <div className="flex gap-2">
        <button onClick={() => setFilter('all')} className={cn('rounded-full px-3.5 py-1.5 text-xs font-semibold', filter === 'all' ? 'bg-ink-950 text-white' : 'bg-ink-900/5 text-ink-900/60')}>
          All ({messages.length})
        </button>
        <button onClick={() => setFilter('new')} className={cn('rounded-full px-3.5 py-1.5 text-xs font-semibold', filter === 'new' ? 'bg-ink-950 text-white' : 'bg-ink-900/5 text-ink-900/60')}>
          Unread ({messages.filter((m) => m.status === 'new').length})
        </button>
      </div>

      <div className="mt-5 flex flex-col gap-3">
        {filtered.length === 0 && <p className="text-sm text-ink-900/40">No messages here.</p>}
        {filtered.map((message) => (
          <div key={message.id} className="rounded-xl2 border border-ink-900/8 bg-white p-5 shadow-card">
            <div className="flex items-start justify-between gap-4">
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <p className="font-medium text-ink-950">{message.name}</p>
                  {message.status === 'new' && <span className="rounded-full bg-brand-50 px-2 py-0.5 text-[10px] font-semibold text-brand-600">New</span>}
                </div>
                <a href={`mailto:${message.email}`} className="text-sm text-brand-600 hover:underline">{message.email}</a>
                <p className="mt-2 whitespace-pre-line text-sm text-ink-900/70">{message.message}</p>
                <p className="mt-1 text-xs text-ink-900/40">{formatDate(message.created_at)}</p>
              </div>
              <div className="flex shrink-0 flex-col items-end gap-1.5">
                {message.status !== 'read' && (
                  <button disabled={pending} onClick={() => startTransition(() => setMessageStatus(message.id, 'read'))} className="text-xs font-semibold text-brand-600 hover:text-brand-700">
                    Mark read
                  </button>
                )}
                {message.status !== 'archived' && (
                  <button disabled={pending} onClick={() => startTransition(() => setMessageStatus(message.id, 'archived'))} className="text-xs font-semibold text-ink-900/60 hover:text-ink-900">
                    Archive
                  </button>
                )}
                <ConfirmDeleteButton onDelete={() => deleteMessage(message.id)} />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
