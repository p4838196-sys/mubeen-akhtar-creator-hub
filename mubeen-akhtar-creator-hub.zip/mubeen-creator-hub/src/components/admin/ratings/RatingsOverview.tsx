import { StarDisplay } from '@/components/ui/StarRating';
import { EmptyState } from '@/components/ui/EmptyState';
import type { RatingSummary } from '@/lib/types/database.types';

export function RatingsOverview({
  photoSummary,
  videoSummary,
}: {
  photoSummary: RatingSummary;
  videoSummary: RatingSummary;
}) {
  const sections = [
    { label: 'Photos', summary: photoSummary },
    { label: 'Videos', summary: videoSummary },
  ];

  return (
    <div className="grid gap-4 sm:grid-cols-2">
      {sections.map(({ label, summary }) => (
        <div key={label} className="rounded-xl2 border border-ink-900/8 bg-white p-5 shadow-card">
          <p className="text-xs font-medium uppercase tracking-wide text-ink-900/40">{label}</p>
          {summary.count > 0 ? (
            <>
              <div className="mt-2 flex items-center gap-2">
                <span className="font-display text-2xl font-bold text-ink-950">{summary.average?.toFixed(1)}</span>
                <StarDisplay value={summary.average ?? 0} size="sm" />
              </div>
              <p className="mt-1 text-xs text-ink-900/40">{summary.count} rating{summary.count !== 1 ? 's' : ''}</p>
              <div className="mt-3 flex flex-col gap-1">
                {[5, 4, 3, 2, 1].map((star) => {
                  const value = summary.distribution[star as 1 | 2 | 3 | 4 | 5];
                  const pct = summary.count > 0 ? (value / summary.count) * 100 : 0;
                  return (
                    <div key={star} className="flex items-center gap-2 text-xs text-ink-900/50">
                      <span className="w-3">{star}</span>
                      <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-ink-900/8">
                        <div className="h-full rounded-full bg-brand-500" style={{ width: `${pct}%` }} />
                      </div>
                      <span className="w-6 text-right">{value}</span>
                    </div>
                  );
                })}
              </div>
            </>
          ) : (
            <div className="mt-3"><EmptyState title="No ratings yet" /></div>
          )}
        </div>
      ))}
    </div>
  );
}
