'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useState } from 'react';
import { cn } from '@/lib/utils/cn';
import { logoutAction } from '@/lib/actions/auth';

const NAV = [
  { href: '/admin', label: 'Overview', exact: true },
  { href: '/admin/photos', label: 'Photos' },
  { href: '/admin/albums', label: 'Albums' },
  { href: '/admin/videos', label: 'Videos' },
  { href: '/admin/social', label: 'Social Accounts' },
  { href: '/admin/reviews', label: 'Reviews' },
  { href: '/admin/ratings', label: 'Ratings' },
  { href: '/admin/messages', label: 'Contact Messages' },
  { href: '/admin/settings', label: 'Website Settings' },
];

function NavLinks({ onNavigate }: { onNavigate?: () => void }) {
  const pathname = usePathname();
  return (
    <nav className="flex flex-col gap-0.5">
      {NAV.map((item) => {
        const active = item.exact ? pathname === item.href : pathname.startsWith(item.href);
        return (
          <Link
            key={item.href}
            href={item.href}
            onClick={onNavigate}
            className={cn(
              'rounded-lg px-3.5 py-2.5 text-sm font-medium transition-colors',
              active ? 'bg-white text-ink-950' : 'text-white/60 hover:bg-white/5 hover:text-white'
            )}
          >
            {item.label}
          </Link>
        );
      })}
    </nav>
  );
}

export function AdminSidebar({ email }: { email: string | null }) {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <>
      {/* Desktop sidebar */}
      <aside className="hidden w-64 shrink-0 flex-col bg-ink-950 p-5 lg:flex">
        <p className="px-3 font-display text-base font-bold text-white">Admin Dashboard</p>
        {email && <p className="mt-0.5 truncate px-3 text-xs text-white/40">{email}</p>}
        <div className="mt-6 flex-1">
          <NavLinks />
        </div>
        <form action={logoutAction}>
          <button className="w-full rounded-lg px-3.5 py-2.5 text-left text-sm font-medium text-white/60 hover:bg-white/5 hover:text-white">
            Log out
          </button>
        </form>
      </aside>

      {/* Mobile top bar + drawer */}
      <div className="flex items-center justify-between border-b border-ink-900/8 bg-ink-950 px-4 py-3 lg:hidden">
        <p className="font-display text-base font-bold text-white">Admin Dashboard</p>
        <button
          aria-label={mobileOpen ? 'Close menu' : 'Open menu'}
          onClick={() => setMobileOpen((v) => !v)}
          className="flex h-9 w-9 items-center justify-center rounded-full text-white hover:bg-white/10"
        >
          <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="1.8">
            {mobileOpen ? (
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 6l12 12M18 6L6 18" />
            ) : (
              <path strokeLinecap="round" strokeLinejoin="round" d="M4 7h16M4 12h16M4 17h16" />
            )}
          </svg>
        </button>
      </div>
      {mobileOpen && (
        <div className="border-b border-white/10 bg-ink-950 p-4 lg:hidden">
          <NavLinks onNavigate={() => setMobileOpen(false)} />
          <form action={logoutAction} className="mt-2">
            <button className="w-full rounded-lg px-3.5 py-2.5 text-left text-sm font-medium text-white/60 hover:bg-white/5 hover:text-white">
              Log out
            </button>
          </form>
        </div>
      )}
    </>
  );
}
