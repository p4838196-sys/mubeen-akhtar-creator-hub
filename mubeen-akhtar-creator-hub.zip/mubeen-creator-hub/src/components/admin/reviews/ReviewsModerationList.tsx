'use client';

import { useState, useTransition } from 'react';
import { StarDisplay } from '@/components/ui/StarRating';
import { setReviewStatus, setReviewFeatured, deleteReview } from '@/lib/actions/admin-reviews';
import { ConfirmDeleteButton } from '@/components/admin/ConfirmDeleteButton';
import { timeAgo } from '@/lib/utils/format';
import type { Review, ReviewStatus } from '@/lib/types/database.types';
import { cn } from '@/lib/utils/cn';

const TABS: { key: ReviewStatus | 'all'; label: string }[] = [
  { key: 'pending', label: 'Pending' },
  { key: 'approved', label: 'Approved' },
  { key: 'hidden', label: 'Hidden' },
  { key: 'all', label: 'All' },
];

export function ReviewsModerationList({ reviews }: { reviews: Review[] }) {
  const [tab, setTab] = useState<ReviewStatus | 'all'>('pending');
  const [pending, startTransition] = useTransition();

  const filtered = tab === 'all' ? reviews : reviews.filter((r) => r.status === tab);

  return (
    <div>
      <div className="flex gap-2">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={cn(
              'rounded-full px-3.5 py-1.5 text-xs font-semibold',
              tab === t.key ? 'bg-ink-950 text-white' : 'bg-ink-900/5 text-ink-900/60'
            )}
          >
            {t.label} {t.key !== 'all' && `(${reviews.filter((r) => r.status === t.key).length})`}
          </button>
        ))}
      </div>

      <div className="mt-5 flex flex-col gap-3">
        {filtered.length === 0 && <p className="text-sm text-ink-900/40">No reviews in this category.</p>}
        {filtered.map((review) => (
          <div key={review.id} className="rounded-xl2 border border-ink-900/8 bg-white p-5 shadow-card">
            <div className="flex items-start justify-between gap-4">
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <p className="font-medium text-ink-950">{review.display_name}</p>
                  <StarDisplay value={review.stars} size="sm" />
                </div>
                <p className="mt-1 text-sm text-ink-900/70">{review.message}</p>
                <p className="mt-1 text-xs text-ink-900/40">
                  {timeAgo(review.created_at)} · {review.status}
                  {review.is_featured && ' · Featured'}
                </p>
              </div>
              <div className="flex shrink-0 flex-col items-end gap-1.5">
                {review.status !== 'approved' && (
                  <button disabled={pending} onClick={() => startTransition(() => setReviewStatus(review.id, 'approved'))} className="text-xs font-semibold text-green-600 hover:text-green-700">
                    Approve
                  </button>
                )}
                {review.status !== 'hidden' && (
                  <button disabled={pending} onClick={() => startTransition(() => setReviewStatus(review.id, 'hidden'))} className="text-xs font-semibold text-ink-900/60 hover:text-ink-900">
                    Hide
                  </button>
                )}
                <button disabled={pending} onClick={() => startTransition(() => setReviewFeatured(review.id, !review.is_featured))} className="text-xs font-semibold text-brand-600 hover:text-brand-700">
                  {review.is_featured ? 'Unfeature' : 'Feature'}
                </button>
                <ConfirmDeleteButton onDelete={() => deleteReview(review.id)} />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
